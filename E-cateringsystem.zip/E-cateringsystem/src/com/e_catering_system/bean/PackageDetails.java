package com.e_catering_system.bean;


public class PackageDetails{
	private int pack_details_id;
	//private int list_of_food_item_id;
	public int getPack_details_id() {
		return pack_details_id;
	}
	public void setPack_details_id(int pack_details_id) {
		this.pack_details_id = pack_details_id;
	}
	
	
}