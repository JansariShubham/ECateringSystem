package com.e_catering_system.bean;

public class Order extends PackageCust{
	private String order_id;
	private String event_date;
	private String order_date;
	private int user_id;
	private int package_id;
	private int total_order_price;
	private int numOfGuest;
	private String payMode;
	private String orderStatus;
	private String paymentStatus;
	private User user_capsule;
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getEvent_date() {
		return event_date;
	}
	public void setEvent_date(String event_date) {
		this.event_date = event_date;
	}
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getPackage_id() {
		return package_id;
	}
	public void setPackage_id(int package_id) {
		this.package_id = package_id;
	}
	public int getTotal_order_price() {
		return total_order_price;
	}
	public void setTotal_order_price(int total_order_price) {
		this.total_order_price = total_order_price;
	}
	public int getNumOfGuest() {
		return numOfGuest;
	}
	public void setNumOfGuest(int numOfGuest) {
		this.numOfGuest = numOfGuest;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public User getUser_capsule() {
		return user_capsule;
	}
	public void setUser_capsule(User user_capsule) {
		this.user_capsule = user_capsule;
	}
	
}
