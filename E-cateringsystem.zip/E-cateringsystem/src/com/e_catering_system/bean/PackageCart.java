package com.e_catering_system.bean;

import java.util.List;

public class PackageCart extends User{
	private int pack_cart_id;
	private int package_id;
	private Food_items food_item_capsule;
	private int curr_price;
	private int curr_qty;
	
	
	private PackageCust packageCapsule;
	
	public int getPack_cart_id() {
		return pack_cart_id;
	}
	public void setPack_cart_id(int pack_cart_id) {
		this.pack_cart_id = pack_cart_id;
	}

	public int getPackage_id() {
		return package_id;
	}
	public void setPackage_id(int package_id) {
		this.package_id = package_id;
	}
	public Food_items getFood_item_capsule() {
		return food_item_capsule;
	}
	public void setFood_item_capsule(Food_items food_item_capsule) {
		this.food_item_capsule = food_item_capsule;
	}
	public int getCurr_price() {
		return curr_price;
	}
	public void setCurr_price(int curr_price) {
		this.curr_price = curr_price;
	}
	public int getCurr_qty() {
		return curr_qty;
	}
	public void setCurr_qty(int curr_qty) {
		this.curr_qty = curr_qty;
	}
	public PackageCust getPackageCapsule() {
		return packageCapsule;
	}
	public void setPackageCapsule(PackageCust packageCapsule) {
		this.packageCapsule = packageCapsule;
	}
	

}
