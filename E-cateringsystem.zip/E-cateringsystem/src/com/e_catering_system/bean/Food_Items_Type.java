package com.e_catering_system.bean;

public class Food_Items_Type {
	private int food_items_type_id;
	private String food_items_type_name;
	public int getFood_items_type_id() {
		return food_items_type_id;
	}
	public void setFood_items_type_id(int food_items_type_id) {
		this.food_items_type_id = food_items_type_id;
	}
	public String getFood_items_type_name() {
		return food_items_type_name;
	}
	public void setFood_items_type_name(String food_items_type_name) {
		this.food_items_type_name = food_items_type_name;
	}
	
}
