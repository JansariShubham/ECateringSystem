package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class EditPackageInfo
 */
public class EditPackageInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditPackageInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String pack_id = request.getParameter("p_id");
		System.out.println("Pack_id Edit" + pack_id);
		String getName = request.getParameter("name").trim().toLowerCase();
		String getType = request.getParameter("packType").trim().toLowerCase();
		String getDescription = request.getParameter("description").toLowerCase().trim();
		String getEvent = request.getParameter("eventName").toLowerCase().trim();
		PackageCust obj = new PackageCust();
		obj.setPackage_name(getName);
		obj.setPackage_type(getType);
		int package_id = Integer.parseInt(pack_id);
		obj.setPackage_id(package_id);
		obj.setPackage_description(getDescription);
		obj.setEvent_name(getEvent);
		
		
		int ans = cservices.editPackageInfo(obj);
		
		if(ans == 0) {
			System.out.println("Update Package Failed!");
			RequestDispatcher rdis = request.getRequestDispatcher("404.jsp");
			rdis.forward(request, response);
		}
		else
		{
			List<Integer> getFoodItemIdOfPackage = new ArrayList<Integer>();
			getFoodItemIdOfPackage = cservices.getFoodItemIdFromPackge(obj.getPackage_id());
			
			for(Integer x: getFoodItemIdOfPackage)
				System.out.println(x + "->");
			request.setAttribute("package_info", obj);
			request.setAttribute("package_id", obj.getPackage_id());
			request.setAttribute("getFoodItemIdOfPackage", getFoodItemIdOfPackage);
			RequestDispatcher rdis = request.getRequestDispatcher("edit_package_cart.jsp");
			rdis.forward(request, response);
			System.out.println("Update Package Success :3");
		}		
	}

}
