package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.bean.User;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class saveOrderUserDetails
 */
public class saveOrderUserDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveOrderUserDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String user_id = (String)request.getParameter("user_id");
		String package_id = (String)request.getParameter("package_id");
		String getAddress = request.getParameter("address").trim();
		int usr_id = Integer.parseInt(user_id);
		int pack_id = Integer.parseInt(package_id);
		int ans = cservices.updateUserAddress(usr_id, getAddress);
		
		if(ans == 0)
			System.out.println("\nError Occured!");
		else {
			User obj = new User();
			obj = cservices.getUserDetailsUsingID(usr_id);
			request.setAttribute("userBean", obj);
			request.setAttribute("package_id", pack_id);
			List<PackageCart> listCart = new ArrayList<PackageCart>();
			listCart = cservices.getPackageCartList(pack_id);
			request.setAttribute("packageCartList", listCart);
			
			PackageCust packageDetails = new PackageCust();
			packageDetails = cservices.getPackageBean(pack_id);
			
			HttpSession userS = request.getSession(false);
			User upuser = (User)userS.getAttribute("LoggedUser");
			upuser.setUser_address(getAddress);
			int onePackPrice = 0;
			for(PackageCart x : listCart)
				onePackPrice += x.getCurr_price();
			request.setAttribute("OnePackPrice", onePackPrice);
			request.setAttribute("packageBean", packageDetails);
			RequestDispatcher rdis = request.getRequestDispatcher("orderGatewayPage.jsp");
			rdis.forward(request, response);
		}
		
	}

}
