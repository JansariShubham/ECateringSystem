package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class GetSelectedPackageType
 */
public class GetSelectedPackageType extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetSelectedPackageType() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		List<Integer> getPackageTypeList = new ArrayList<Integer>();
		
		getPackageTypeList = cservices.getPackageIdList();
		
		
		request.setAttribute("getPackageTypeList", getPackageTypeList);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String eventpacktype = request.getParameter("packType");
		List<Integer> getPackageTypeList = new ArrayList<Integer>();
		if(eventpacktype == null)
		{
			System.out.println("Event Not Pack Type Not found!");
		}
		else
		{
			System.out.println("Found: " + eventpacktype);
			String data[] = eventpacktype.split(",");
			//if(!data[0].trim().equalsIgnoreCase("all"))	
				getPackageTypeList = cservices.getPackageTypeList(eventpacktype);
		}
	
		for(Integer x: getPackageTypeList)
		{
			System.out.print(" -> " + x);
		}
		request.setAttribute("getPackageTypeList", getPackageTypeList);
		//request.getRequestDispatcher("show_package_list.jsp").forward(request, response);
	}

}
