package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Food_items;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class SearchFood
 */
public class SearchFood extends HttpServlet {
	CateringServices cservices = new CateringServicesImpl();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchFood() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String foodName = request.getParameter("foodSearch");
		System.out.println("Food Name: " + foodName);
		
				
		List<Food_items> obj = new ArrayList<Food_items>();
		obj = cservices.fetchParticularFoodItemdetail(foodName.toLowerCase());
		request.setAttribute("foodBean", obj);
		RequestDispatcher rdis = request.getRequestDispatcher("showSerachFood.jsp");
		rdis.forward(request, response);
//		response.sendRedirect("showSerachFood.jsp")
	}

}
