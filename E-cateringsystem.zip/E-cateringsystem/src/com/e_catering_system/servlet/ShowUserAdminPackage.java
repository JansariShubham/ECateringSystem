package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class ShowUserAdminPackage
 */
public class ShowUserAdminPackage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowUserAdminPackage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		List<PackageCust> userPackageList = new ArrayList<PackageCust>();
		
		userPackageList = cservices.getPackList();
		System.out.println("Hello Package list" + userPackageList);
		
		
			int adminCount =0;
			int userCount =0;
			for(PackageCust x: userPackageList)
			{
				if(!x.getPackage_type().equalsIgnoreCase("customize"))
					adminCount++;
				else
					userCount++;
			}
			request.setAttribute("userCount", userCount);
			request.setAttribute("adminCount", adminCount);
			request.setAttribute("userPackageList", userPackageList);
		
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
