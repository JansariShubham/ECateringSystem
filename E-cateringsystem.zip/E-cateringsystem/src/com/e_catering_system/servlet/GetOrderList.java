package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Order;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class GetOrderList
 */
public class GetOrderList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetOrderList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		List<Order> orderList = new ArrayList<Order>();
		orderList = cservices.getOrderList();
		if(orderList == null)
			System.out.println("Error in fetch order list!");
		
		System.out.println("Order List");
		
		
		request.setAttribute("orderList", orderList);
		//request.getRequestDispatcher("admin_report.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	
	
		String stDate = request.getParameter("startdate");
		String enDate = request.getParameter("enddate");
		System.out.println("Date: " + stDate + ", " + enDate);
		List<Order> getList = new ArrayList<Order>();
		getList = cservices.getReportOrder(stDate, enDate);
		System.out.println("Hello There Order List");
		for(Order x: getList)
		{
			System.out.print(x.getOrder_id() + ", " + x.getOrder_date() + ", " + x.getEvent_name());
		}
		request.setAttribute("orderList", getList);
		request.getRequestDispatcher("admin_report.jsp").forward(request, response);
	}

}
