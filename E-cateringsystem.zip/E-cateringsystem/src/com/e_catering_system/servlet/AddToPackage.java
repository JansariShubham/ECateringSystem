package com.e_catering_system.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.e_catering_system.bean.List_of_food_items;
import com.e_catering_system.bean.User;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class AddToPackage
 */
public class AddToPackage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddToPackage() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath())
		String pid2 = (String)request.getParameter("pro_id");
		System.out.print(pid2);
		String package_id = request.getParameter("getPackId");
		System.out.println("\nPackage ID2: " + package_id);
		String user_id = request.getParameter("us_id");
		System.out.println("\nUser id: " + user_id);
		if(pid2 == "9999")
		{
			System.out.println("Create!");
		}
		else
		{
			int pid = Integer.parseInt(pid2);
			int pack_id = Integer.parseInt(package_id);
			int userID = Integer.parseInt(user_id);
			System.out.println(userID);
			int reply = cservices.setFoodItemIdIntoPackageCart(pid, pack_id, userID);
			if(reply == 0)
			{
				response.getWriter().append("false");
				System.out.println("Error during saving id into cart!");
			}
			else
			{
				response.getWriter().append("true");
				System.out.println("Success! + " + pid);
			}
		}
		/*
		 * System.out.println("\nPAckage ID: " + package_id); List_of_food_items obj =
		 * new List_of_food_items(); obj.setPackage_id(Integer.parseInt(package_id));
		 * obj.setFood_item_id(Integer.parseInt(product_id)); int getResult =
		 * cservices.setListOfFoodItems(obj);
		 */
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
