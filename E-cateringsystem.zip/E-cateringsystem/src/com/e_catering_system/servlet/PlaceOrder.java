package com.e_catering_system.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Order;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class PlaceOrder
 */
public class PlaceOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlaceOrder() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("Hello! Online Payment!");
		String usr_id = request.getParameter("user_id");
		String pack_id = request.getParameter("package_id");
		String eventDate = (String)request.getParameter("event_date");
		String orderID = request.getParameter("order_id");
		String totalAmt = request.getParameter("total_order_price");
		String payMode = request.getParameter("paymethod");
		String numOfGuest = request.getParameter("numGuest");
		System.out.println(usr_id + " - " + pack_id + " - " + eventDate + " - " + orderID + " - " + totalAmt + " - " + payMode + " - " + numOfGuest);
	
		int user_id = Integer.parseInt(usr_id);
		int package_id = Integer.parseInt(pack_id);
		//int order_id = Integer.parseInt(orderID);
		int total_order_price = Integer.parseInt(totalAmt);
		int guestNumber = Integer.parseInt(numOfGuest);
		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");  
		String strDate= formatter.format(date);
		Order order = new Order();
		order.setOrder_id(orderID);
		order.setPackage_id(package_id);
		order.setUser_id(user_id);
		order.setEvent_date(eventDate);
		order.setTotal_order_price(total_order_price);
		order.setOrder_date(strDate);
		order.setPayMode(payMode);
		order.setNumOfGuest(guestNumber);
		int isOrder = cservices.setOrderDetails(order);
		if(isOrder != 0)
		{
			System.out.println("ORder Details Saved Sucess!");
		}
		else
		{
			System.out.println("Order Details Save Failed!");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String usr_id = request.getParameter("user_id");
		String pack_id = request.getParameter("package_id");
		String eventDate = (String)request.getParameter("event_date");
		String orderID = request.getParameter("order_id");
		String totalAmt = request.getParameter("total_order_price");
		String payMode = request.getParameter("paymethod");
		String numOfGuest = request.getParameter("numGuest");
		System.out.println(usr_id + " - " + pack_id + " - " + eventDate + " - " + orderID + " - " + totalAmt + " - " + payMode + " - " + numOfGuest);
	
		int user_id = Integer.parseInt(usr_id);
		int package_id = Integer.parseInt(pack_id);
		//int order_id = Integer.parseInt(orderID);
		int total_order_price = Integer.parseInt(totalAmt);
		int guestNumber = Integer.parseInt(numOfGuest);
		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
		String strDate= formatter.format(date);
		Order order = new Order();
		order.setOrder_id(orderID);
		order.setPackage_id(package_id);
		order.setUser_id(user_id);
		order.setEvent_date(eventDate);
		order.setTotal_order_price(total_order_price);
		order.setOrder_date(strDate);
		order.setPayMode(payMode);
		order.setNumOfGuest(guestNumber);
		int isOrder = cservices.setOrderDetails(order);
	
			System.out.println("Aye! Cash On Delivery!");
			System.out.println("Cod Date: " + strDate);
			String getEventName = cservices.getEventNameFromPackage(package_id);
			request.setAttribute("orderBean", order);
			request.setAttribute("event_name", getEventName);
			RequestDispatcher rdis = request.getRequestDispatcher("thankYouPage.jsp");
			rdis.forward(request, response);
	}
}
/*
Date date = new Date();  
SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
String strDate= formatter.format(date); 
*/