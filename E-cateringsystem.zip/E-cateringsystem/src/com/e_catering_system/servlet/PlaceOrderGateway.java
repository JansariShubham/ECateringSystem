package com.e_catering_system.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.User;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class PlaceOrderGateway
 */
public class PlaceOrderGateway extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlaceOrderGateway() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		String pack_id = request.getParameter("package_id");
	
		String usr_id = request.getParameter("user_id");
	
		
		int package_id = Integer.parseInt(pack_id);
		int user_id = Integer.parseInt(usr_id);
		
		User obj = new User();
		
		
		obj = cservices.getUserDetailsUsingID(user_id);
		
		request.setAttribute("userBean", obj);
		request.setAttribute("package_id", package_id);
		RequestDispatcher rdis = request.getRequestDispatcher("getUserDetails.jsp");
		rdis.forward(request, response);
		//System.out.println("USer Id and Package Id: " + usr_id + "\t" + pack_id);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
