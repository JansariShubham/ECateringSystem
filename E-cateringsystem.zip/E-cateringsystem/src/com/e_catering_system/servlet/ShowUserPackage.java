package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class ShowUserPackage
 */
public class ShowUserPackage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowUserPackage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String ordid = request.getParameter("ord_id").trim();
	
		Order obj = new Order();
		obj = cservices.getOrderDetailsUsingOrderId(ordid);
		
		List<PackageCart> listPackageCart = new ArrayList<PackageCart>();
		
		listPackageCart = cservices.getPackageCartList2(obj.getPackage_id(),obj.getUser_capsule().getUser_id());
	
		request.setAttribute("listPackageCart", listPackageCart);
		request.setAttribute("orderObject", obj);
		
		request.getRequestDispatcher("user_order.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
