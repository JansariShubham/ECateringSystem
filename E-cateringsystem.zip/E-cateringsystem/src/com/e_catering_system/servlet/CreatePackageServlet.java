package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.User;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class CreatePackageServlet
 */
public class CreatePackageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreatePackageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String user_id = request.getParameter("user_id");
		String user_role = request.getParameter("user_role");
		String pack_id = request.getParameter("package_id");
		String food_id = request.getParameter("cur_food_item");
		String total_package_price = request.getParameter("total_package_price");
		int userId = Integer.parseInt(user_id);
		int total_pack_price = Integer.parseInt(total_package_price);
		int package_id = Integer.parseInt(pack_id);
		String getQty = request.getParameter("cur_qtys");
		String getPrices = request.getParameter("cur_prices");
		System.out.println(getQty + "\n" + getPrices + "\n" + food_id);
		
		String[] arrQty = getQty.trim().split(" ");
		String[] arrPrices = getPrices.trim().split(" ");
		String[] arrFoodId = food_id.trim().split(" ");
		List<PackageCart> listCart = new ArrayList<PackageCart>();
		listCart = cservices.getPackageCartList(package_id);
		int count = 0;
		for(PackageCart temp : listCart)
		{
			System.out.println(temp.getFood_item_capsule().getFood_item_name() + " -> " + arrQty[count] + " - >" + arrPrices[count]);
			count++;
		}
		int batchResult = cservices.setPackageCartQuantityAndPrice(package_id, arrQty, arrPrices, arrFoodId);
		if(batchResult > 0)
			System.out.println("Batch Added Successfully");
		else
			System.out.println("Batch Added Failed!");
		if(user_role.trim().equals("1")) {
			//RequestDispatcher rdis = request.getRequestDispatcher();
			System.out.println("Admin");
			int tot_price = 0;
			for(String y : arrPrices)
			{
				tot_price += Integer.parseInt(y);
			}
			int ans = cservices.setPackagePrice(package_id, tot_price);
			if(ans == 0)
				System.out.println("Price Update Failed!");
			else
				System.out.println("Price Updated!");
			
			RequestDispatcher rdis = request.getRequestDispatcher("show_package_list.jsp");
			rdis.forward(request, response);
		}
		else
		{
			System.out.println("User!");
			
			User obj = new User();
			obj = cservices.getUserDetailsUsingID(userId);
			request.setAttribute("userBean", obj);
			System.out.println("Package ID: " + package_id);
			request.setAttribute("package_id", package_id);
			RequestDispatcher rdis = request.getRequestDispatcher("getUserDetails.jsp");
			rdis.forward(request, response);
		}
	}
}
