package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.User;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class ShowOrderDetails
 */
public class ShowOrderDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowOrderDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		String getOrder_id = request.getParameter("order_id");
		
		System.out.println("Order ID: " + getOrder_id);
		
		int user_id = cservices.getUserIdOrderId(getOrder_id); 
		
		if(user_id == 0)
		{
			RequestDispatcher rdis = request.getRequestDispatcher("404.jsp");
			rdis.forward(request, response);
		}
		else
		{
			
			System.out.println("USER Order ID: " + user_id);
			Order orderObj = new Order();
			
			orderObj = cservices.getOrderDetailsUsingOrderId(getOrder_id);
			System.out.println(orderObj.getEvent_name());
			if(orderObj == null)
			{
				System.out.println("404Error!");
			}
			else
			{
				
				List<PackageCart> listPackageCart = new ArrayList<PackageCart>();
				listPackageCart = cservices.getPackageCartList2(orderObj.getPackage_id(), user_id);
				
				request.setAttribute("orderObject", orderObj);
				request.setAttribute("listPackageCart", listPackageCart);
				
				RequestDispatcher rdis = request.getRequestDispatcher("requestedOrderDetails.jsp");
				rdis.forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String getEventDate = request.getParameter("datePicker");
		System.out.println("Event - Date: " + getEventDate);
		String getUserID = request.getParameter("user_id");
		String package_id = request.getParameter("package_id");
		
		String getTotalOrderPrice = request.getParameter("total_order_price");
		String getNumberGuest = request.getParameter("uguest");
		
		String paymethod = request.getParameter("pay_mthd");
		
		
		//System.out.println(getUserID + ", " + package_id + ", " + getTotalOrderPrice + ", " + getNumberGuest + ", " + paymethod);
		
		int pack_id = Integer.parseInt(package_id);
		int total_order_price = Integer.parseInt(getTotalOrderPrice);
		int guestNumber = Integer.parseInt(getNumberGuest);
		User userBean = cservices.getUserDetailsUsingID(Integer.parseInt(getUserID));

		String getEventName = cservices.getEventNameFromPackage(pack_id);
		
		request.setAttribute("userBean", userBean);
		request.setAttribute("event_date", getEventDate);
		request.setAttribute("event_name", getEventName);
		request.setAttribute("package_id", pack_id);
		request.setAttribute("total_order_price", total_order_price);
		request.setAttribute("guestNumber", guestNumber);
		request.setAttribute("paymethod", paymethod);
		
		if(paymethod.equalsIgnoreCase("cash on delivery"))
		{
			RequestDispatcher rdis = request.getRequestDispatcher("showUserOrderDetailsCash.jsp");
			rdis.forward(request, response);
		}
		else
		{
			System.out.println("\nOnline Page REdirect!");
			RequestDispatcher rdis = request.getRequestDispatcher("showUserOrderDetails.jsp");
			rdis.forward(request, response);
		}
		//doGet(request, response);
	}

}
