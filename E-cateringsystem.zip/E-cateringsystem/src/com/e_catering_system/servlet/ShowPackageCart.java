package com.e_catering_system.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class ShowPackageCart
 */
public class ShowPackageCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowPackageCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String getPackID = request.getParameter("pack_id2");
		System.out.println("GEt ShowCart Pack" + getPackID);
		
		List<PackageCart> packageCartList = new ArrayList<PackageCart>();
		int package_id = Integer.parseInt(getPackID);
		packageCartList = cservices.getPackageCartList(package_id);
		
		if(packageCartList != null)
		{
			request.setAttribute("packageCartList", packageCartList);
			RequestDispatcher rdis = request.getRequestDispatcher("showPackageCartDetails.jsp");
			rdis.forward(request, response);
		}
		else
		{
			System.out.println("\nError During Package Cart List!!!\n");
			response.sendRedirect("404.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
