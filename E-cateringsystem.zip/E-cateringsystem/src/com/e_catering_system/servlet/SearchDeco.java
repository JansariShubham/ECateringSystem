package com.e_catering_system.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Decoration;
import com.e_catering_system.bean.Food_items;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;

/**
 * Servlet implementation class SearchDeco
 */
public class SearchDeco extends HttpServlet {
	CateringServices cservices = new CateringServicesImpl();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchDeco() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String decoName = request.getParameter("decoSearch");
		System.out.println("Deco Name: " + decoName);
		
		
		int deco_id = cservices.fetchDecoName(decoName);
		if(deco_id != 0)
		{
			System.out.println("deco item id: " + deco_id);
		}
		
		Decoration obj = cservices.fetchParticularDecoItemdetail(deco_id);
		request.setAttribute("decoBean", obj);
		RequestDispatcher rdis = request.getRequestDispatcher("showSerachDeco.jsp");
		rdis.forward(request, response);
		

		//doGet(request, response);
	}

}
