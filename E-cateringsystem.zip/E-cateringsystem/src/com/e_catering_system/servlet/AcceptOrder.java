package com.e_catering_system.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.User;
import com.e_catering_system.services.CateringServices;
import com.e_catering_system.services.impl.CateringServicesImpl;
import com.e_catering_system.util.ThreadEmail;

/**
 * Servlet implementation class AcceptOrder
 */
public class AcceptOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CateringServices cservices = new CateringServicesImpl();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AcceptOrder() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		String order_id = request.getParameter("order_id");
		String user_id = request.getParameter("user_id");

		System.out.println("User ID: " + user_id);
		int usr_id = Integer.parseInt(user_id);
		int accept = cservices.acceptUserOrder(usr_id, order_id);
		if (accept != 0) {
			User obj = new User();
			obj = cservices.getUserDetailsUsingID(usr_id);
			Order orderObject = cservices.getOrderDetailsUsingOrderId(order_id);
			System.out.println("Accept Order Success!");

			String composeMail = "HELLO " + obj.getUser_name().toUpperCase() + ",<br> YOUR ORDER IS ACCEPTED!<br>LOCATION: " + obj.getUser_address().toUpperCase() + "<br>EVENT NAME: " + orderObject.getEvent_name().toUpperCase() + "<br>EVENT DATE: " + orderObject.getEvent_date() + "<br>TOTAL PRICE: " + orderObject.getTotal_order_price() + " RS<br>PAYMENT STATUS: ";
			
			if(orderObject.getPaymentStatus().equalsIgnoreCase("Pending"))
				composeMail = composeMail + "PENDING<br>";
			else
				composeMail = composeMail + "PAID<br>";
			composeMail = composeMail + "NUMBER OF GUESTS: " + String.valueOf(orderObject.getNumOfGuest()) + ".";
			String title = "ORDER ACCEPTATION";  
			try {
				ThreadEmail threadObj = new ThreadEmail(obj.getUser_email(), composeMail, title);
				threadObj.start();
				RequestDispatcher rdis = request.getRequestDispatcher("BookingOrderList.jsp");
				rdis.forward(request, response);
			} catch (Exception e) {
				System.out.println("Mail Exception : " + e.getMessage());
			}
		} else {
			System.out.println("\nReject Order Failed!\n");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
