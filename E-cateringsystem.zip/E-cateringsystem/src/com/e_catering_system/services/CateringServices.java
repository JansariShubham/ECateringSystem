package com.e_catering_system.services;
import java.util.ArrayList;

import com.e_catering_system.bean.Decoration;
import com.e_catering_system.bean.Event;
import com.e_catering_system.bean.Feedback;
import com.e_catering_system.bean.Food_items;
import com.e_catering_system.bean.List_of_food_items;
import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.bean.User;
import java.util.List;
public interface CateringServices {

	int saveUserDetails(User obj);

	public int checkMailStatus(String email);

	User checkLoginDetails(User obj2);

	User getUserData(String email);

	User setUserNewPassword(User obj, String password);

	int saveProductDetails(Food_items obj);

	List<User> fetchUserList();

	int getCategoryId(String getCategory);

	List<Food_items> fetchProductList();


	Food_items getProductDetails(int pid);

	int deleteProductDetails(int product_id);

	int updateProductDetails(Food_items obj);

	List<String> getCategoryList();

	int savePackageInfo(PackageCust obj);

	int getPackId(PackageCust obj);

	//int setPackageData(List_of_food_items obj);

	int saveDecorationDetails(Decoration obj);

	List<Decoration> getDecoList();

	List_of_food_items getPackageInfo(int pid);

	List<Event> fetchEventList();

	int fetchFoodName(String foodName);

	List<Food_items> fetchParticularFoodItemdetail(String foodName);

	List<PackageCust> getPackList();

	int setFoodItemIdIntoPackageCart(int pid, int pack_id, int userID);

	List<PackageCart> getPackageCartList(int package_id);

	List<PackageCart> removeFoodItemFromCart(int foodID, int packID);

	int setPackagePrice(int package_id, int total_pack_price);

	User getUserDetailsUsingID(int userId);

	int updateUserAddress(int usr_id, String getAddress);

	PackageCust getPackageBean(int package_id);

	int setPackageCartQuantityAndPrice(int package_id, String[] arrQty, String[] arrPrices, String[] arrFoodId);

	String getEventNameFromPackage(int pack_id);

	int fetchDecoName(String decoName);

	Decoration fetchParticularDecoItemdetail(int deco_id);

	int setOrderDetails(Order order);

	List<Order> getOrderList();

	int getUserIdOrderId(String getOrder_id);

	Order getOrderDetailsUsingOrderId(String getOrder_id);

	List<PackageCart> getPackageCartList2(int package_id, int user_id);

	int rejectUserOrder(int usr_id, String order_id);

	int acceptUserOrder(int usr_id, String order_id);

	List<PackageCart> getAdminPackageList();

	List<Integer> getPackageIdList();

	List<PackageCust> getPackageCustList();

	int editPackageInfo(PackageCust obj);

	List<Integer> getFoodItemIdFromPackge(int package_id);

	List<Integer> getPackageTypeList(String eventpacktype);

	int editUserProfile(User userDetailsObj);

	List<Order> getUserOrderList(int user_id);

	int deleteAdminPackage(int package_id);

	List<PackageCust> getUserPackageIdList(int user_id);

	int compareEventDate(String getEventDate);

	//int setFeedbackData(int user_id, String message);

	int setFeedbackData(int user_id, String message);

	List<Feedback> fetchFeedBackList();

	int removeFeedback(int feedback_id);

	int addCategory(String catname);

	List<Order> getReportOrder(String stDate, String enDate);

	int changeOrderStatusToComplete(String order_id, int usr_id);


	//List<com.e_catering_system.servlet.User> fetchUserList();

}
