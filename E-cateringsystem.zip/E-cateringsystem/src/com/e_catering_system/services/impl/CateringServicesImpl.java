package com.e_catering_system.services.impl;

import java.sql.Connection;
import java.sql.DriverManager;

import com.e_catering_system.bean.Decoration;
import com.e_catering_system.bean.Event;
import com.e_catering_system.bean.Feedback;
import com.e_catering_system.bean.Food_items;
import com.e_catering_system.bean.List_of_food_items;
import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.bean.User;
import com.e_catering_system.dao.CateringDao;
import com.e_catering_system.dao.impl.CateringDaoImpl;
import com.e_catering_system.services.CateringServices;
import java.util.List;
import java.util.ArrayList;

public class CateringServicesImpl implements CateringServices {

	CateringDao cdao = new CateringDaoImpl();

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_catering_system", "root",
					"admin");
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int saveUserDetails(User obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.saveUserDetailsData(obj, con);
				con.close();
				return ans;
			} else {
				System.out.println("\n\n\t\tConnection Unsucessfull!\n");
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int checkMailStatus(String email) {
		// TODO Auto-generated method stub

		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.getMailDetails(email, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public User checkLoginDetails(User obj2) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				User ans = new User();
				
				//int ans = 0; 
				ans = cdao.checkLoginStatus(obj2, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public User getUserData(String email) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				User ans = cdao.getUserDetailsUsingEmail(email, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Error : " + e.getMessage());
		}

		return null;
	}

	@Override
	public User setUserNewPassword(User obj, String password) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				User ans = cdao.setUpassword(obj, password, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int saveProductDetails(Food_items obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.saveProductDetails(con,obj);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<User> ans = new ArrayList<User>();
				ans = cdao.fetchUserListDao(con);
				for(User x : ans)
				{
					System.out.println("\nNameS: " + x.getUser_name());
				}
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display User List Error: " + e.getMessage());
		}
		return null;
	}

	@Override
	public int getCategoryId(String getCategory) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.fetchCategoryId(con,getCategory);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<Food_items> fetchProductList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Food_items> ans = new ArrayList<Food_items>();
				ans = cdao.fetchProductListDao(con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Product List Error: " + e.getMessage());
		}

		return null;
	}

	@Override
	public Food_items getProductDetails(int pid) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				Food_items ans = cdao.getProductDetailsId(con, pid);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int deleteProductDetails(int product_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.deleteProduct(con,product_id);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public int updateProductDetails(Food_items obj) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello SErver Layer!\n");
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.updateProduct(con,obj);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<String> getCategoryList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				List<String> ans = new ArrayList<String>();
				ans = cdao.getCategoryList(con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int savePackageInfo(PackageCust obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				int ans = cdao.savePackageInfo(obj, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Error : " + e.getMessage());
		}
		return 0;
	}

	@Override
	public int getPackId(PackageCust obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				int ans = cdao.getPackageId(obj, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Error : " + e.getMessage());
		}
		return 0;
	}


	/*public int setPackageData(List_of_food_items obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				int ans = cdao.setPackageData(obj,con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Error : " + e.getMessage());
		}

		return 0;
	}*/

	@Override
	public int saveDecorationDetails(Decoration obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.saveDecoDetails(con,obj);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			System.out.println("Exception Decoration SErvice: " + e.getMessage());
		}

		return 0;
	}

	@Override
	public List<Decoration> getDecoList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Decoration> ans = new ArrayList<Decoration>();
				ans = cdao.fetchDecoList(con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display User List Error: " + e.getMessage());
		}

		return null;
	}

	@Override
	public List_of_food_items getPackageInfo(int pid) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				List_of_food_items ans = new List_of_food_items();
				ans = cdao.getPackageInfo(pid, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Event> fetchEventList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Event> ans = new ArrayList<Event>();
				ans = cdao.fetchEventListDao(con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Event List Error: " + e.getMessage());
		}
	
		return null;
	}

	
	public int fetchFoodName(String foodName) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.getFoodName(foodName, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
		return 0;
	}

	
	public List<Food_items> fetchParticularFoodItemdetail(String foodName) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				List<Food_items> obj = new ArrayList<Food_items>();
				
				obj = cdao.selectParticularFoodItemDetail(foodName, con); 
				con.close();
				return obj;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	

		return null;
	}

	public List<PackageCust> getPackList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<PackageCust> ans = new ArrayList<PackageCust>();
				ans = cdao.fetchPackList(con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display PAckage List Error: " + e.getMessage());
		}

		return null;
	}

	
	@Override
	public int setFoodItemIdIntoPackageCart(int pid, int pack_id, int userID) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.setFoodItemIdIntoCart(pid, pack_id, userID, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. During Store PRoduct ID: " + pid);
		}
		return 0;
	}

	@Override
	public List<PackageCart> getPackageCartList(int package_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		System.out.println("\nSErvice Package Cart called");
		List<PackageCart> ans = new ArrayList<PackageCart>();
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				System.out.println("\nSErvice Package Cart");
				ans = cdao.fetchPackageCartList(package_id, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			System.out.println("Package Cart List Exp: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<PackageCart> removeFoodItemFromCart(int foodID, int packID) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				List<PackageCart> ans = new ArrayList<PackageCart>();
				ans = cdao.removeFoodItemFromPackageCart(foodID, packID, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Error : " + e.getMessage());
		}

		return null;
	}

	@Override
	public int setPackagePrice(int package_id, int total_pack_price) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.setPackageTotalPrice(package_id, total_pack_price, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. During Store PRoduct ID: " + package_id);
		}
		return 0;
	}

	@Override
	public User getUserDetailsUsingID(int userId) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				User ans = cdao.getUserDetailsUsingId(userId, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Error : " + e.getMessage());
		}

		return null;
	}

	@Override
	public int updateUserAddress(int usr_id, String getAddress) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.setUserAddress(usr_id, getAddress, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. During Store Address: ");
		}
		return 0;
	}

	@Override
	public PackageCust getPackageBean(int package_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			System.out.println("\nConnection MEssage: " + e.getMessage());
		}
		try {
			if (con != null) {
				PackageCust ans = cdao.getPackageBean(package_id, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
				System.out.println("\nService Package Error : " + e.getMessage());
		}

		return null;
	}

	@Override
	public int setPackageCartQuantityAndPrice(int package_id, String[] arrQty, String[] arrPrices, String[] arrFoodId) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.updatePackageCartQtyPrice(con, package_id, arrQty, arrPrices, arrFoodId);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			System.out.println("Add Batch Service Error : " + e.getMessage());
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public String getEventNameFromPackage(int pack_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				String ans = new String();
				
				//int ans = 0; 
				ans = cdao.getEventName(pack_id, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return null;
	}

	
	public int fetchDecoName(String decoName) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.getdecoName(decoName, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	

		
		return 0;
	}

	
	public Decoration fetchParticularDecoItemdetail(int deco_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				Decoration obj = new Decoration();
				
				obj = cdao.selectParticularDecoItemDetail(deco_id, con); 
				con.close();
				return obj;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return null;
	}

	@Override
	public int setOrderDetails(Order order) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.setOrderDetails(order, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nService Set ORder: " + e.getMessage());
		}
		return ans;
	}

	@Override
	public List<Order> getOrderList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				List<Order> obj = new ArrayList<Order>();
				obj = cdao.fetchOrderList(con); 
				con.close();
				return obj;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int getUserIdOrderId(String getOrder_id) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.fetchOrderUserId(getOrder_id,con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. During Ser User Id ID!");
		}

		return 0;
	}

	@Override
	public Order getOrderDetailsUsingOrderId(String getOrder_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				Order obj = new Order();
				obj = cdao.fetchOrderDetails(getOrder_id, con); 
				con.close();
				return obj;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<PackageCart> getPackageCartList2(int package_id, int user_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		System.out.println("\nSErvice Package Cart called");
		List<PackageCart> ans = new ArrayList<PackageCart>();
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				System.out.println("\nSErvice Package Cart");
				ans = cdao.fetchPackageCartList2(package_id, user_id,con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			System.out.println("Package Cart List Exp: " + e.getMessage());
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public int rejectUserOrder(int usr_id, String order_id) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.rejectUserOrder(usr_id, order_id, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. during reject order: " + e.getMessage());
		}

		return 0;
	}

	@Override
	public int acceptUserOrder(int usr_id, String order_id) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.acceptUserOrder(usr_id, order_id, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. during reject order: " + e.getMessage());
		}
		return 0;
	}

	@Override
	public List<PackageCart> getAdminPackageList() {
		// TODO Auto-generated method stub
		Connection con = null;
		System.out.println("\nSErvice Admin Package Cart called");
		List<PackageCart> ans = new ArrayList<PackageCart>();
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				System.out.println("\nSErvice Admin Package Cart");
				ans = cdao.fetchAdminPackageList(con); 
				con.close();
				
				for(PackageCart x : ans)
				{
					System.out.println("Name: " + x.getPackageCapsule().getEvent_name() + " " + x.getPackageCapsule().getPackage_id() + " " + x.getPackageCapsule().getPackage_name());
				}
				
				
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			System.out.println("Package Admin Cart List Exp: " + e.getMessage());
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Integer> getPackageIdList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Integer> ans = new ArrayList<Integer>();
				ans = cdao.fetchPackageIDList(con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display User List Error: " + e.getMessage());
		}

		return null;
	}

	
	public List<PackageCust> getPackageCustList() {
		// TODO Auto-generated method stub
		
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<PackageCust> ans = new ArrayList<PackageCust>();
				ans = cdao.fetchPackageList(con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display User List Error: " + e.getMessage());
		}
		
		return null;
	}

	@Override
	public int editPackageInfo(PackageCust obj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				//PackageCust ans = new PackageCust();
				int ans = cdao.updateAdminPackage(obj, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. during update package: " + e.getMessage());
		}

		return 0;
	}

	@Override
	public List<Integer> getFoodItemIdFromPackge(int package_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Integer> ans = new ArrayList<Integer>();
				ans = cdao.fetchFoodListFromPackage(package_id, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Food id package List Error: " + e.getMessage());
		}
		return null;
	}

	@Override
	public List<Integer> getPackageTypeList(String eventpacktype) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Integer> ans = new ArrayList<Integer>();
				ans = cdao.fetchTypeOfPackageList(eventpacktype, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Type package List Error: " + e.getMessage());
		}

		return null;
	}

	
	public int editUserProfile(User userDetailsObj) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				int ans = 0;
				ans = cdao.updateUserDetails(userDetailsObj, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Type package List Error: " + e.getMessage());
		}

		return 0;
	}

	@Override
	public List<Order> getUserOrderList(int user_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<Order> ans = new ArrayList<Order>();
				ans = cdao.fetchOrderUserList(user_id, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Type package List Error: " + e.getMessage());
		}

		return null;
	}

	@Override
	public int deleteAdminPackage(int package_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				
				int ans = cdao.deleteAdminPackage(package_id, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Type package List Error: " + e.getMessage());
		}
		return 0;
	}

	@Override
	public List<PackageCust> getUserPackageIdList(int user_id) {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
		
				List<PackageCust> ans = new ArrayList<PackageCust>();
				ans = cdao.fetchUserPackId(user_id, con);

				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Display Type package List Error: " + e.getMessage());
		}

		return null;
	}

	@Override
	public int compareEventDate(String getEventDate) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				ans = cdao.checkEventDate(getEventDate, con);
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nExc. during compare date: " + e.getMessage());
		}
		return ans;
	}

	
	public int setFeedbackData(int user_id, String message) {
		// TODO Auto-generated method stub
		
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				int ans = cdao.saveFeedbackData(user_id, message,con);
				con.close();
				return ans;
			} else {
				System.out.println("\n\n\t\tConnection Unsucessfull!\n");
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
		return 0;
	}

	
	public List<Feedback> fetchFeedBackList() {
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				List<Feedback> listFeed = new ArrayList<Feedback>();
				 listFeed = cdao.fetchFeedbackData(con);
				con.close();
				return listFeed;
			} else {
				System.out.println("\n\n\t\tConnection Unsucessfull!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int removeFeedback(int feedback_id) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.removeFeedback(feedback_id, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nService remove feed : " + e.getMessage());
		}
		return 0;
	}

	@Override
	public int addCategory(String catname) {
		// TODO Auto-generated method stub
		
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.addCategory(catname, con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nService add cate : " + e.getMessage());
		}
		
		
		return 0;
	}

	@Override
	public List<Order> getReportOrder(String stDate, String enDate) {
		// TODO Auto-generated method stub
		
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				List<Order> listFeed = new ArrayList<Order>();
				 listFeed = cdao.fetchReportData(stDate, enDate, con);
				con.close();
				return listFeed;
			} else {
				System.out.println("\n\n\t\tConnection Unsucessfull!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public int changeOrderStatusToComplete(String order_id, int usr_id) {
		// TODO Auto-generated method stub
		int ans = 0;
		Connection con = null;
		try {
			con = getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				
				ans = cdao.setOrderComplete(order_id, usr_id,con); 
				con.close();
				return ans;
			} else {
				System.out.println("\nConnection Failed!\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nService add cate : " + e.getMessage());
		}
		return 0;
	}
}
