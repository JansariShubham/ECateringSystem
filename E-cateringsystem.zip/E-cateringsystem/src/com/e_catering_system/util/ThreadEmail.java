package com.e_catering_system.util;

import com.e_catering_system.bean.User;

public class ThreadEmail extends Thread
{
	String sendemail=null;
	String msg=null;
	String title = null;
	public ThreadEmail() {}
	public ThreadEmail(String email,String message, String title)
	{
		sendemail=email;
		msg=message;
		this.title = title;
	}
	User u = new User();

	@Override
	public void run() {
		try {
			System.out.println(msg);
			System.out.println(sendemail);
			SendEmail s = new SendEmail();
			String mail = sendemail;
			s.sendmail(mail, msg, title);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
