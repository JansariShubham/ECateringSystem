package com.e_catering_system.util;

public class PaytmConstants {
	public final static String MID = "HTgHTm10625559528245";
	public final static String MERCHANT_KEY = "Sk%&DleHomg#sPXq";

//	public final static String MID = "XVvIKC99526660849837";
//	public final static String MERCHANT_KEY = "7xviXno1q2h58voP";

	
	public final static String INDUSTRY_TYPE_ID = "Retail";
	public final static String CHANNEL_ID = "WEB";
	public final static String WEBSITE = "WEBSTAGING";
	public final static String PAYTM_URL = "https://securegw-stage.paytm.in/theia/v1/processTransaction";

}
