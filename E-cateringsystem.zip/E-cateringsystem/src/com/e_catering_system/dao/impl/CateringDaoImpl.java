package com.e_catering_system.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.e_catering_system.bean.Decoration;
import com.e_catering_system.bean.Encryption;
import com.e_catering_system.bean.Event;
import com.e_catering_system.bean.Feedback;
import com.e_catering_system.bean.Food_items;
import com.e_catering_system.bean.List_of_food_items;
import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.bean.User;
import com.e_catering_system.dao.CateringDao;
import java.util.List;
import java.util.ArrayList;
import java.util.Base64;

public class CateringDaoImpl implements CateringDao {

	@Override
	public int saveUserDetailsData(User obj, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;

		String insertQuery = "insert into user_table(user_name, user_contact, user_email, user_password, user_role) values (?,?,?,?,?)";
		try (PreparedStatement pst = con.prepareStatement(insertQuery)) {
			// pst.setInt(1, 3);
			pst.setString(1, obj.getUser_name());

			System.out.println(obj.getUser_name());
			pst.setString(2, obj.getUser_contact());
			pst.setString(3, obj.getUser_email());

			Encryption e1 = new Encryption();
			String enc = e1.encyptText(obj.getUser_password());
			pst.setString(4, enc);
			pst.setInt(5, 0);
			ans = pst.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("\n\nData Saved Unsucess!\n");
		}
		return ans;
	}

	@Override
	public int getMailDetails(String email, Connection con) {
		// TODO Auto-generated method stub
		int ans = 1;
		try {
			/*
			 * String query = "select * from user_table where user_email = " + email + ";";
			 * PreparedStatement pst = con.prepareStatement(query); int ans = 1; ResultSet
			 * rst = pst.executeQuery();
			 * 
			 * if(rst.next()) { if(email.equalsIgnoreCase(rst.getString("user_email"))) {
			 * ans = 0; } }
			 * 
			 * pst.close(); rst.close(); return ans;
			 */

			try (PreparedStatement ps = con.prepareStatement("select * from user_table");
					ResultSet resultset = ps.executeQuery()) {
				while (resultset.next()) {
					if (email.equalsIgnoreCase(resultset.getString("user_email"))) {
						ans = 0;
						break;
					}
				}

			}

			return ans;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ans;
	}

	@Override
	public User checkLoginStatus(User obj2, Connection con) {
		// TODO Auto-generated method stub
		// User ans2 = new User();
		User ans = new User();
		int flag = 0;
		try {
			String email = obj2.getUser_email();
			String password = obj2.getUser_password();

			System.out.println("\n" + password);
			try (PreparedStatement ps = con.prepareStatement("select * from user_table");
					ResultSet resultset = ps.executeQuery()) {
				while (resultset.next()) {
					Encryption e1 = new Encryption();
					String dec = e1.decryptText(resultset.getString("user_password"));
					if (email.equalsIgnoreCase(resultset.getString("user_email")) && password.equals(dec)) {

						System.out.println(resultset.getInt(1) + " \t " + resultset.getString("user_email"));
						ans.setUser_id(resultset.getInt(1));
						ans.setUser_name(resultset.getString("user_name"));
						ans.setUser_email(resultset.getString("user_email"));

						ans.setUser_password(dec);
						ans.setUser_contact(resultset.getString("user_contact"));
						ans.setUser_role(resultset.getInt("user_role"));
						ans.setUser_address(resultset.getString("user_address"));
						flag = 1;
						break;
					}
				}

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		if (flag == 0)
			ans = null;
		System.out.println("Answer : " + ans);
		return ans;
	}

	public User getUserDetailsUsingEmail(String email, Connection con) {
		// TODO Auto-generated method stub
		User ans = new User();
		int flag = 0;
		PreparedStatement ps = null;
		ResultSet resultset = null;
		System.out.println("Email: " + email);
		String gquery = "select * from user_table where user_email = ?;";
		try {
			ps = con.prepareStatement(gquery);
			ps.setString(1, email);
			resultset = ps.executeQuery();
			while (resultset.next()) {
				System.out.println(resultset.getInt(1) + " \t " + resultset.getString("user_email"));
				ans.setUser_id(resultset.getInt(1));
				ans.setUser_name(resultset.getString("user_name"));
				ans.setUser_email(resultset.getString("user_email"));
				Encryption e1 = new Encryption();
				String dec = e1.decryptText(resultset.getString("user_password"));
				ans.setUser_password(dec);
				ans.setUser_contact(resultset.getString("user_contact"));
				ans.setUser_role(resultset.getInt("user_role"));
				ans.setUser_address(resultset.getString("user_address"));
				System.out.println("\nUser Data: " + resultset.getString("user_name"));
				flag = 1;
				break;
			}
		} catch (Exception e) {
			System.out.println("\nGetting User Data Exception : " + e.getMessage());
		}
		System.out.println("\nGetting Email Data: " + ans);
		if (flag == 0)
			return null;
		return ans;
	}

	@Override
	public User setUpassword(User obj, String password, Connection con) {
		// TODO Auto-generated method stub
		User ans = new User();
		// int flag = 0;
		PreparedStatement ps = null;
		ans.setUser_contact(obj.getUser_contact());
		ans.setUser_email(obj.getUser_email());
		ans.setUser_name(obj.getUser_name());
		ans.setUser_id(obj.getUser_id());
		ans.setUser_role(obj.getUser_role());
		//ans.setUser_address(obj.getUser_address());
		int userID = obj.getUser_id();
		String gquery = "update user_table set user_password = ? where user_id = ?";
		try {
			ps = con.prepareStatement(gquery);
			Encryption e1 = new Encryption();
			//String dec = e1.decryptText(password);
			String ec = e1.encyptText(password);
			ps.setString(1, ec);
			ps.setInt(2, userID);
			int resultValue = ps.executeUpdate();
			if (resultValue == 0) {
				return null;
			} else {
				ans.setUser_password(password);
				return ans;
			}
		} catch (Exception e) {
			System.out.println("\nGetting User Data Exception : " + e.getMessage());
		}
		return ans;
	}

	@Override
	public int saveProductDetails(Connection con, Food_items obj) {
		// TODO Auto-generated method stub
		String query = "insert into food_items(food_item_name, food_item_price, food_item_image, description, food_item_type_id, food_item_cat, food_qty) values (?, ?, ?, ?, ?, ?, ?)";

		try (PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
			pst.setString(1, obj.getFood_item_name());
			pst.setInt(2, obj.getFood_item_price());
			pst.setBlob(3, obj.getFoodItemImage());
			pst.setString(4, obj.getDescription());
			pst.setInt(5, obj.getFood_item_type_id());
			pst.setString(6, obj.getFoodType());
			pst.setInt(7, obj.getFood_qty());
			int x = pst.executeUpdate();

			return x;
		} catch (Exception e) {
			System.out.println("\nFood ITem Upload Exception: " + e.getMessage());
		}
		return 0;
	}

	@Override
	public List<User> fetchUserListDao(Connection con) {
		// TODO Auto-generated method stub
		List<User> list_of_user = new ArrayList<User>();
		try (PreparedStatement ps = con.prepareStatement("select * from user_table");
				ResultSet resultset = ps.executeQuery()) {
			while (resultset.next()) {
				User ans = new User();
				System.out.println(resultset.getInt(1) + " \t " + resultset.getString("user_email"));
				if (resultset.getInt("user_role") == 1)
					continue;
				ans.setUser_id(resultset.getInt(1));
				ans.setUser_name(resultset.getString("user_name"));
				ans.setUser_email(resultset.getString("user_email"));
				Encryption e1 = new Encryption();
				String dec = e1.decryptText(resultset.getString("user_password"));
				ans.setUser_password(dec);
				ans.setUser_contact(resultset.getString("user_contact"));
				ans.setUser_role(resultset.getInt("user_role"));
				ans.setUser_address(resultset.getString("user_address"));
				list_of_user.add(ans);
			}
		} catch (Exception e) {
			System.out.println("\nDao USer List: " + e.getMessage());
		}
		for (User x : list_of_user) {
			System.out.println("\nNameDao: " + x.getUser_name());
		}
		return list_of_user;
	}

	@Override
	public int fetchCategoryId(Connection con, String getCategory) {
		// TODO Auto-generated method stub
		int flag = 0;
		PreparedStatement ps = null;
		ResultSet resultset = null;
		String gquery = "select * from food_item_type where food_item_type_name = ?";
		try {
			ps = con.prepareStatement(gquery);
			ps.setString(1, getCategory);
			resultset = ps.executeQuery();
			while (resultset.next()) {
				flag = resultset.getInt(1);
				return flag;
			}
		} catch (Exception e) {
			System.out.println("\nException Category Id: " + e.getMessage());
		} finally {
			try {
				ps.close();
				resultset.close();
			} catch (Exception e) {
				System.out.println("Exception Final Category: " + e.getMessage());
			}
		}
		return 0;
	}

	public List<Food_items> fetchProductListDao(Connection con) {
		// TODO Auto-generated method stub
		List<Food_items> list_of_product = new ArrayList<Food_items>();
		try (PreparedStatement ps = con.prepareStatement("select * from food_items");
				ResultSet resultset = ps.executeQuery()) {
			while (resultset.next()) {
				Food_items ans = new Food_items();
				ans.setFood_item_id(resultset.getInt(1));
				ans.setFood_item_name(resultset.getString(3));
				ans.setFood_items_type_id(resultset.getInt(2));
				try {
					PreparedStatement ps2 = null;
					ResultSet rs2 = null;
					String query = "select food_item_type_name from food_item_type where food_item_type_id = ?";
					ps2 = con.prepareStatement(query);
					ps2.setInt(1, ans.getFood_items_type_id());
					rs2 = ps2.executeQuery();
					while (rs2.next()) {
						ans.setFood_items_type_name(rs2.getString("food_item_type_name"));
						// System.out.println("\nCategory Name Dao: " + ans.getFood_items_type_name() +
						// "\t Name: " + ans.getFood_item_name());
					}
					ps2.close();
				} catch (Exception e) {
					System.out.println("\nException during category name: " + e.getMessage());
				}
				ans.setFood_qty(resultset.getInt("food_qty"));
				ans.setFood_item_price(resultset.getInt(5));
				ans.setDescription(resultset.getString(4));
				ans.setFoodType(resultset.getString("food_item_cat"));
				byte[] imageData = resultset.getBytes(6);
				if (null != imageData && imageData.length > 0) {
					String imageString = Base64.getEncoder().encodeToString(imageData);
					ans.setFoodItemImageString(imageString);
				}
				list_of_product.add(ans);
			}
		} catch (Exception e) {
			System.out.println("\nDao USer List: " + e.getMessage());
		}
		return list_of_product;

	}

	@Override
	public Food_items getProductDetailsId(Connection con, int pid) {
		// TODO Auto-generated method stub
		Food_items ans = new Food_items();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement("select * from food_items where food_item_id = ?");
			ps.setInt(1, pid);
		} catch (Exception e) {
		}
		try (ResultSet resultset = ps.executeQuery()) {
			while (resultset.next()) {
				String catName = new String();
				ans.setFood_item_id(resultset.getInt(1));
				ans.setFood_item_name(resultset.getString(3));
				ans.setFood_item_price(resultset.getInt(5));
				ans.setFood_items_type_id(resultset.getInt(2));
				ans.setFoodType(resultset.getString("food_item_cat"));
				try (PreparedStatement pst = con.prepareStatement(
						"select food_item_type_name from food_item_type where food_item_type_id = ?")) {
					pst.setInt(1, ans.getFood_items_type_id());
					ResultSet rst = pst.executeQuery();
					while (rst.next()) {
						catName = rst.getString("food_item_type_name");
					}
				} catch (Exception e) {
					System.out.println("Exception during category name: " + e.getMessage());
				}
				ans.setFood_items_type_name(catName);
				ans.setFood_qty(resultset.getInt("food_qty"));
				ans.setDescription(resultset.getString(4));

				byte[] imageData = resultset.getBytes(6);
				if (null != imageData && imageData.length > 0) {
					String imageString = Base64.getEncoder().encodeToString(imageData);
					ans.setFoodItemImageString(imageString);
				}
			}
		} catch (Exception e) {
			System.out.println("\nDao Product: " + e.getMessage());
		}

		return ans;
	}

	public int deleteProduct(Connection con, int product_id) {
		// TODO Auto-generated method stub
		PreparedStatement pst = null;
		String query = "delete from food_items where food_item_id = ?";
		try {
			pst = con.prepareStatement(query);
			pst.setInt(1, product_id);
			int ans = pst.executeUpdate();
			return ans;
		} catch (Exception e) {
			System.out.println("Exception Occured Delete Product : " + e.getMessage());
		}
		return 0;
	}

	@Override
	public int updateProduct(Connection con, Food_items obj) {
		// TODO Auto-generated method stub
		System.out.println("\nDao Layer Hello!");
		PreparedStatement pst = null;
		String query = "update food_items set food_item_name = ?, food_item_type_id = ?, food_item_price = ?, description = ?, food_item_image = COALESCE(?,food_item_image), food_item_cat = ?, food_qty = ? where food_item_id = ?";
		try {
			pst = con.prepareStatement(query);
			pst.setString(1, obj.getFood_item_name());
			pst.setInt(2, obj.getFood_items_type_id());
			pst.setInt(3, obj.getFood_item_price());
			pst.setString(4, obj.getDescription());
			// if(obj.getFoodItemImage() != null)
			pst.setBlob(5, obj.getFoodItemImage());
			pst.setString(6, obj.getFoodType());
			pst.setInt(7, obj.getFood_qty());
			pst.setInt(8, obj.getFood_item_id());
			// System.out.println("\nFood Item ID: " + obj.getFood_item_id());

			int ans = pst.executeUpdate();
			System.out.println("Answer: " + ans);
			return ans;
		} catch (Exception e) {
			System.out.println("Update Product Exp: " + e.getMessage());
		}
		return 0;
	}

	@Override
	public List<String> getCategoryList(Connection con) {
		// TODO Auto-generated method stub
		List<String> ans = new ArrayList<String>();
		try (PreparedStatement ps = con.prepareStatement("select * from food_item_type");
				ResultSet resultset = ps.executeQuery()) {
			while (resultset.next()) {
				String categoryName = new String();
				categoryName = resultset.getString(2);
				ans.add(categoryName.toLowerCase());
			}
		} catch (Exception e) {
			System.out.println("\nException during getting Category List: " + e.getMessage());
		}
		return ans;
	}

	@Override
	public int savePackageInfo(PackageCust obj, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		int flag = 0;
		int event_id = 0;
		String query = "insert into package_table(package_name, package_description, package_type, event_id) values (?, ?, ?, ?)";
		try (PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
			pst.setString(1, obj.getPackage_name());
			pst.setString(2, obj.getPackage_description());
			pst.setString(3, obj.getPackage_type());

			try (PreparedStatement pst2 = con
					.prepareStatement("select event_id from event_table where event_name = ?")) {
				pst2.setString(1, obj.getEvent_name().toLowerCase());
				ResultSet rst2 = pst2.executeQuery();
				while (rst2.next()) {
					event_id = rst2.getInt(1);
					break;
				}
			} catch (Exception e) {
				System.out.println("Exception during event_id: " + e.getMessage());
			}
			pst.setInt(4, event_id);
			ans = pst.executeUpdate();
			// System.out.println("\nReturn GEn Key: " + Statement.RETURN_GENERATED_KEYS);
			return ans;
		} catch (Exception e) {
			System.out.println("\nException Dao Save PAckage: " + e.getMessage());
		}
		return 0;
	}

	public int getPackageId(PackageCust obj, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		try (PreparedStatement pst = con.prepareStatement(
				"select package_id from package_table where package_name = ? AND package_type = ? AND event_id = ?")) {
			pst.setString(1, obj.getPackage_name());
			pst.setString(2, obj.getPackage_type().toLowerCase());
			int event_id = 0;
			try (PreparedStatement pst2 = con
					.prepareStatement("select event_id from event_table where event_name = ?")) {
				pst2.setString(1, obj.getEvent_name().toLowerCase());
				ResultSet rst2 = pst2.executeQuery();
				while (rst2.next()) {
					event_id = rst2.getInt(1);
					break;
				}
			} catch (Exception e) {
				System.out.println("\nException Occured get package id: " + e.getMessage());
			}
			pst.setInt(3, event_id);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				ans = rst.getInt(1);
				System.out.println("Dao PAckage ID: " + ans);
			}
		} catch (Exception e) {
			System.out.println("Exception Getting Package ID: " + e.getMessage());
		}
		return ans;
	}

	/*
	 * public static int getPackageDetailsId(int package_id, Connection con) { int
	 * ans = 0; String query =
	 * "select package_details_id from package_details_table where package_id = ?";
	 * try (PreparedStatement pst = con.prepareStatement(query)) { pst.setInt(1,
	 * package_id); ResultSet rst = pst.executeQuery(); while (rst.next()) { ans =
	 * rst.getInt(1); } } catch (Exception e) {
	 * System.out.print("\nException During PAckage Details ID: " + e.getMessage());
	 * } System.out.println("\nPackage Details ID: " + ans); return ans; }
	 * 
	 * public static int setPackageDetailsId(List_of_food_items obj, int
	 * packdetails_id, Connection con) { int ans = 0; String query =
	 * "update package_table set pack_details_id = ? where package_id = ?"; try
	 * (PreparedStatement pst = con.prepareStatement(query)) { pst.setInt(1,
	 * obj.getPackage_id()); ans = pst.executeUpdate(); } catch (Exception e) {
	 * System.out.println("\nExp. During Set Package Details Id: " +
	 * e.getMessage()); } return ans; }
	 * 
	 * /*@Override public int setPackageData(List_of_food_items obj, Connection con)
	 * { // TODO Auto-generated method stub int ans = 0; String query =
	 * "insert into package_details_table(package_id) values (?)"; try
	 * (PreparedStatement pst = con.prepareStatement(query,
	 * Statement.RETURN_GENERATED_KEYS)) { pst.setInt(1, obj.getPackage_id()); ans =
	 * pst.executeUpdate(); } catch (Exception e) {
	 * System.out.println("Error During Set PAckage: " + e.getMessage()); } if (ans
	 * != 0) { int getPackageDetailsId = getPackageDetailsId(obj.getPackage_id(),
	 * con); obj.setPack_details_id(getPackageDetailsId); int condition =
	 * setPackageDetailsId(obj, getPackageDetailsId, con); if (condition != 0) {
	 * query =
	 * "insert into list_of_food_item(package_details_id, food_item_id) values (?, ?)"
	 * ; try (PreparedStatement pst = con.prepareStatement(query)) {
	 * 
	 * } catch (Exception e) { System.out.println("\nException during "); } } }
	 * return ans; }
	 */

	@Override
	public int saveDecoDetails(Connection con, Decoration obj) {
		// TODO Auto-generated method stub
		String query = "insert into decoration_table(deco_description, deco_image, deco_price, deco_name, deco_type) values (?, ?, ?, ?, ?)";

		try (PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
			pst.setString(1, obj.getDeco_description());
			pst.setInt(3, obj.getDeco_price());
			pst.setBlob(2, obj.getDeco_imageStream());
			pst.setString(4, obj.getDeco_name());
			pst.setString(5, obj.getDeco_type());
			int x = pst.executeUpdate();

			return x;
		} catch (Exception e) {
			System.out.println("\nDeco Upload Exception: " + e.getMessage());
		}

		return 0;
	}

	@Override
	public List<Decoration> fetchDecoList(Connection con) {
		// TODO Auto-generated method stub
		List<Decoration> decoList = new ArrayList<Decoration>();
		try (PreparedStatement ps = con.prepareStatement("select * from decoration_table");
				ResultSet resultset = ps.executeQuery()) {
			while (resultset.next()) {
				Decoration ans = new Decoration();
				ans.setDeco_id(resultset.getInt(1));
				ans.setDeco_name(resultset.getString(5));
				ans.setDeco_price(resultset.getInt(4));
				// ans.setDe_email(resultset.getString("user_email"));
				// ans.setUser_password(resultset.getString("user_password"));
				// ans.setUser_contact(resultset.getString("user_contact"));
				ans.setDeco_description(resultset.getString(2));
				byte[] imageData = resultset.getBytes(3);
				if (null != imageData && imageData.length > 0) {
					String imageString = Base64.getEncoder().encodeToString(imageData);
					System.out.println("Image STring: " + imageString);
					ans.setDeco_imageString(imageString);
				}
				decoList.add(ans);
			}
		} catch (Exception e) {
			System.out.println("\nDao Deco List: " + e.getMessage());
		}
		return decoList;
	}

	@Override
	public List_of_food_items getPackageInfo(int pid, Connection con) {
		// TODO Auto-generated method stub
		List_of_food_items ans = new List_of_food_items();
		String query = "select * from package_table where package_id = ?";
		try (PreparedStatement pst = con.prepareStatement(query)) {
			pst.setInt(1, pid);
			String getEventName = new String();
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				ans.setPackage_id(rst.getInt(1));
				ans.setPackage_name(rst.getString("package_name"));
				ans.setPackage_type(rst.getString("package_type"));
				ans.setPackage_description(rst.getString(4));
				ans.setEvent_id(rst.getInt("event_id"));
				try (PreparedStatement pst2 = con
						.prepareStatement("select event_name from event_table where event_id = ?")) {
					pst2.setInt(1, ans.getEvent_id());
					ResultSet rst2 = pst2.executeQuery();
					while (rst2.next()) {
						getEventName = rst2.getString("event_name");
						break;
					}
				} catch (Exception e) {
					System.out.println("\nException during get event name ? >" + e.getMessage());
				}
				ans.setEvent_name(getEventName);
				return ans;
			}
		} catch (Exception e) {
			System.out.println("\nException List Of package" + e.getMessage());
		}
		return null;
	}

	public List<Event> fetchEventListDao(Connection con) {
		// TODO Auto-generated method stub
		List<Event> ans = new ArrayList<Event>();
		try (PreparedStatement ps = con.prepareStatement("select * from event_table");
				ResultSet resultset = ps.executeQuery()) {
			while (resultset.next()) {
				Event obj = new Event();
				obj.setEvent_id(resultset.getInt(1));
				obj.setEvent_name(resultset.getString(2));
				ans.add(obj);
			}
		} catch (Exception e) {
			System.out.println("\nException during getting event List: " + e.getMessage());
		}

		return ans;
	}

	public int getFoodName(String foodName, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		try (PreparedStatement ps = con
				.prepareStatement("select food_item_id from food_items where food_item_name = ?")) {

			ps.setString(1, foodName);
			ResultSet resultset = ps.executeQuery();
			while (resultset.next()) {
				ans = resultset.getInt(1);
			}
			return ans;
		} catch (Exception e) {
			System.out.println("\nException during getting food name: " + e.getMessage());
		}

		return 0;
	}

	public List<Food_items> selectParticularFoodItemDetail(String foodName, Connection con) {
		// TODO Auto-generated method stub
		List<Food_items> objList = new ArrayList<Food_items>();
		try (PreparedStatement ps = con.prepareStatement("select * from food_items where food_item_name LIKE ?")) {
			String getCatName = new String();
			ps.setString(1, "%"+foodName+"%");
			ResultSet resultset = ps.executeQuery();
			while (resultset.next()) {
				Food_items obj = new Food_items();
				obj.setFood_item_id(resultset.getInt(1));
				obj.setFood_items_type_id(resultset.getInt(2));
				try (PreparedStatement pst = con.prepareStatement(
						"select food_item_type_name from food_item_type where food_item_type_id = ?")) {
					pst.setInt(1, obj.getFood_items_type_id());
					ResultSet rst = pst.executeQuery();
					while (rst.next()) {
						getCatName = rst.getString("food_item_type_name");
					}
				} catch (Exception e) {
					System.out.println("Exception Category Name: " + e.getMessage());
				}
				obj.setFood_items_type_name(getCatName);
				obj.setFood_item_name(resultset.getString(3));
				obj.setDescription(resultset.getString(4));
				obj.setFood_item_price(resultset.getInt(5));
				byte[] imageData = resultset.getBytes(6);
				if (null != imageData && imageData.length > 0) {
					String imageString = Base64.getEncoder().encodeToString(imageData);
					System.out.println("Image STring: " + imageString);
					obj.setFoodItemImageString(imageString);
				}

				obj.setFoodType(resultset.getString(7));
				obj.setFood_qty(resultset.getInt(8));
				objList.add(obj);
			}
		} catch (Exception e) {
			System.out.println("\nException during Getting Particular Food Deatil: " + e.getMessage());
		}

		return objList;
	}

	public List<PackageCust> fetchPackList(Connection con) {
		// TODO Auto-generated method stub
		List<PackageCust> ans = new ArrayList<PackageCust>();
		String event_name = new String();
		try (PreparedStatement ps = con.prepareStatement("select * from package_table");
				ResultSet rst = ps.executeQuery()) {

			while (rst.next()) {

				PackageCust obj = new PackageCust();
				obj.setPackage_id(rst.getInt(1));
				obj.setPackage_name(rst.getString(2));
				obj.setPackage_price(rst.getInt(3));
				obj.setPackage_type(rst.getString(5));
				obj.setEvent_id(rst.getInt("event_id"));
				try (PreparedStatement pst2 = con
						.prepareStatement("select event_name from event_table where event_id = ?")) {
					pst2.setInt(1, obj.getEvent_id());
					ResultSet rst2 = pst2.executeQuery();
					while (rst2.next()) {
						event_name = rst2.getString("event_name");
					}
				} catch (Exception e) {
					System.out.println("Exc. during get package list: " + e.getMessage());
				}
				obj.setEvent_name(event_name);
				obj.setPackage_description(rst.getString("package_description"));
				ans.add(obj);
			}
		} catch (Exception e) {
			System.out.println("\nException during getting event List: " + e.getMessage());
		}

		return ans;
	}

	public int setFoodItemIdIntoCart(int pid, int pack_id, int userID, Connection con) {
		// TODO Auto-generated method stub

		int ans = 0;
		try(PreparedStatement pst2 = con.prepareStatement("SELECT COUNT(*) FROM package_cart_table where food_item_id = ? AND package_id = ?")){
			pst2.setInt(1, pid);
			pst2.setInt(2, pack_id);
			
			ResultSet st = pst2.executeQuery();
			int val = 0;
			while(st.next())
			{
				val = st.getInt("count(*)");
			}
			if(val > 0)
				return 0;
			
		}catch(Exception e) {System.out.println("\nError During finding food_item_id : " + e.getMessage());}
		
		String query = "insert into package_cart_table(package_id, user_id, food_item_id) values (?, ?, ?)";
		try (PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
			pst.setInt(1, pack_id);
			pst.setInt(2, userID);
			pst.setInt(3, pid);
			
			ans = pst.executeUpdate();
		} catch (Exception e) {
			System.out.println("\nExc. during set food id into cart! " + e.getMessage());
		}
		return ans;
	}

	public List<PackageCart> fetchPackageCartList(int package_id, Connection con) {
		// TODO Auto-generated method stub
		System.out.println("\nDao Package Cart Called");
		List<PackageCart> listCart = new ArrayList<PackageCart>();
		CateringDaoImpl daoi = new CateringDaoImpl();
		String query = "select * from package_cart_table where package_id = ?";
		try (PreparedStatement pst = con.prepareStatement(query)) {
			System.out.println("\nDao Package Cart");
			pst.setInt(1, package_id);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				PackageCart obj = new PackageCart();
				obj.setPack_cart_id(rst.getInt(1));
				obj.setUser_id(rst.getInt("user_id"));
				obj.setPackage_id(rst.getInt("package_id"));
				int food_id = rst.getInt("food_item_id");
				Food_items foodObj = new Food_items();
				foodObj = daoi.getProductDetailsId(con, food_id);
				obj.setFood_item_capsule(foodObj);
				obj.setCurr_price(rst.getInt("current_food_price"));
				obj.setCurr_qty(rst.getInt("current_food_qty"));
				
				System.out.println("\nGEt PAck : " + obj.getPackage_id() + " " + obj.getPackage_id());
				
				listCart.add(obj);
			}
		} catch (Exception e) {
			System.out.println("\nExc. During Pack Cart List: " + e.getMessage());
		}
		return listCart;
	}

	@Override
	public List<PackageCart> removeFoodItemFromPackageCart(int foodID, int packID, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		String query = "delete from package_cart_table where package_id = ? AND food_item_id = ?";
		try (PreparedStatement pst = con.prepareStatement(query)) {
			pst.setInt(1, packID);
			pst.setInt(2, foodID);
			ans = pst.executeUpdate();
		} catch (Exception e) {
			System.out.println("\nException during remove food item: " + e.getMessage());
		}

		if (ans != 0) {
			List<PackageCart> listCart = new ArrayList<PackageCart>();
			CateringDaoImpl daoi = new CateringDaoImpl();
			query = "select * from package_cart_table where package_id = ?";
			try (PreparedStatement pst = con.prepareStatement(query)) {
				System.out.println("\nDao Package Cart");
				pst.setInt(1, packID);
				ResultSet rst = pst.executeQuery();
				while (rst.next()) {
					PackageCart obj = new PackageCart();
					obj.setPack_cart_id(rst.getInt(1));
					obj.setUser_id(rst.getInt("user_id"));
					
					obj.setPackage_id(rst.getInt("package_id"));
					int food_id = rst.getInt("food_item_id");
					Food_items foodObj = new Food_items();
					foodObj = daoi.getProductDetailsId(con, food_id);
					obj.setFood_item_capsule(foodObj);
					listCart.add(obj);
				}
			} catch (Exception e) {
				System.out.println("\nExc. During Pack Cart List: " + e.getMessage());
			}
			return listCart;
		}

		return null;
	}

	@Override
	public int setPackageTotalPrice(int package_id, int total_pack_price, Connection con) {
		// TODO Auto-generated method stub
		
		int ans = 0;
		String query = "UPDATE package_table set package_price = ? where package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, total_pack_price);
			pst.setInt(2, package_id);
			ans = pst.executeUpdate();
			return ans;
		}
		catch(Exception e) {System.out.println("Exc. during set package price: " + e.getMessage());}
		return ans;
	}

	@Override
	public User getUserDetailsUsingId(int userId, Connection con) {
		// TODO Auto-generated method stub
		User ans = new User();
		int flag = 0;
		PreparedStatement ps = null;
		ResultSet resultset = null;
		String gquery = "select * from user_table where user_id = ?;";
		try {
			ps = con.prepareStatement(gquery);
			ps.setInt(1, userId);
			resultset = ps.executeQuery();
			while (resultset.next()) {
				System.out.println(resultset.getInt(1) + " \t " + resultset.getString("user_email"));
				ans.setUser_id(resultset.getInt(1));
				ans.setUser_name(resultset.getString("user_name"));
				ans.setUser_email(resultset.getString("user_email"));
				Encryption e1 = new Encryption();
				String dec = e1.decryptText(resultset.getString("user_password"));
				ans.setUser_password(dec);
				ans.setUser_address(resultset.getString("user_address"));
				ans.setUser_contact(resultset.getString("user_contact"));
				ans.setUser_role(resultset.getInt("user_role"));
				System.out.println("\nUser Data: " + resultset.getString("user_name"));
				flag = 1;
				break;
			}
		} catch (Exception e) {
			System.out.println("\nGetting User Data Exception : " + e.getMessage());
		}
		System.out.println("\nGetting Email Data: " + ans);
		if (flag == 0)
			return null;
		return ans;
	}

	@Override
	public int setUserAddress(int usr_id, String getAddress, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		String query = "UPDATE user_table SET user_address = ? WHERE user_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1, getAddress);
			pst.setInt(2, usr_id);
			ans = pst.executeUpdate();
			return ans;
		}
		catch(Exception e) {System.out.println("Exp. During store address! " + e.getMessage());}
		return ans;
	}

	
	public PackageCust getPackageBean(int package_id, Connection con) {
		// TODO Auto-generated method stub
		PackageCust ans = new PackageCust();
		String query = "SELECT * FROM package_table WHERE package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setInt(1, package_id);
			System.out.println("Package id!!!!" + package_id);
			ans.setPackage_id(package_id);
			
			ResultSet rst = pst.executeQuery();
			String getEventName = new String();
			while(rst.next()) {
				ans.setEvent_id(rst.getInt("event_id"));
				try (PreparedStatement pst2 = con
						.prepareStatement("select event_name from event_table where event_id = ?")) {
					pst2.setInt(1, ans.getEvent_id());
					ResultSet rst2 = pst2.executeQuery();
					while (rst2.next()) {
						getEventName = rst2.getString("event_name");
						break;
					}
				} catch (Exception e) {
					System.out.println("\nException during get event name ? >" + e.getMessage());
				}
				
				ans.setEvent_name(getEventName);
				ans.setPackage_name(rst.getString("package_name"));
				ans.setPackage_description(rst.getString("package_description"));
				ans.setPackage_price(rst.getInt("package_price"));
				ans.setPackage_type(rst.getString("package_type"));
				return ans;
			}
		}catch(Exception e) {System.out.println("\nException Occured During Package Bean: " + e.getMessage());}
		return ans;
	}

	@Override
	public int updatePackageCartQtyPrice(Connection con, int package_id, String[] arrQty, String[] arrPrices, String[] arrFoodId) {
		// TODO Auto-generated method stub
		//String query = "UPDATE package_cart_table SET current_food_qty = ?, current_food_price = ? WHERE package_id = ?";
		for(String x: arrQty)
			System.out.print(x);
		System.out.println("---");
		for(String y: arrPrices)
			System.out.print(y);
		int ans = 0;
		for(int i = 0; i < arrQty.length; i++)
		{
			String query = "UPDATE package_cart_table SET current_food_qty = ?, current_food_price = ? WHERE package_id = ? AND food_item_id = ?";
			try(PreparedStatement pst = con.prepareStatement(query))
			{
				int qty = Integer.parseInt(arrQty[i]);
				int price = Integer.parseInt(arrPrices[i]);
				int id = Integer.parseInt(arrFoodId[i]);
				
				pst.setInt(1, qty);
				pst.setInt(2, price);
				pst.setInt(3, package_id);
				pst.setInt(4, id);
				
				ans = pst.executeUpdate();
			}
			catch(Exception e)
			{
				System.out.println("\nException Occured AddBatch: " + e.getMessage());
			}
		}
		return ans;
	}

	
	public String getEventName(int pack_id, Connection con) {
		// TODO Auto-generated method stub
		String query = "select event_id from package_table where package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, pack_id);
			
			ResultSet rst = pst.executeQuery();
			while(rst.next())
			{
				int event_id = rst.getInt("event_id");
				try(PreparedStatement pst2 = con.prepareStatement("select event_name from event_table where event_id = ?")){
					pst2.setInt(1, event_id);
					ResultSet rst2 = pst2.executeQuery();
					while(rst2.next())
					{
						String event_name = rst2.getString("event_name");
						return event_name;
					}
				}catch(Exception e) {System.out.println("event _name : " + e.getMessage());
				e.printStackTrace();}
			}
		}catch(Exception e) {System.out.println("\nExp Event NAme: " + e.getMessage());
		e.printStackTrace();}
		return null;
	}

	@Override
	public int getdecoName(String decoName, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		try (PreparedStatement ps = con
				.prepareStatement("select decoration_id from decoration_table where deco_name = ?")) {

			ps.setString(1, decoName);
			ResultSet resultset = ps.executeQuery();
			while (resultset.next()) {
				ans = resultset.getInt(1);
			}
			return ans;
		} catch (Exception e) {
			System.out.println("\nException during getting food name: " + e.getMessage());
		}

		return 0;
	}

	@Override
	public Decoration selectParticularDecoItemDetail(int deco_id, Connection con) {
		// TODO Auto-generated method stub
		Decoration obj = new Decoration();
		try (PreparedStatement ps = con.prepareStatement("select * from decoration_table where decoration_id = ?")) {
			//String getCatName = new String();
			ps.setInt(1, deco_id);
			ResultSet resultset = ps.executeQuery();
			while (resultset.next()) {
				obj.setDeco_id(resultset.getInt(1));
				obj.setDeco_description(resultset.getString(2));
				byte[] imageData = resultset.getBytes(3);
				if (null != imageData && imageData.length > 0) {
					String imageString = Base64.getEncoder().encodeToString(imageData);
					System.out.println("Image STring: " + imageString);
					obj.setDeco_imageString(imageString);
				}
				obj.setDeco_price(resultset.getInt(4));
				obj.setDeco_name(resultset.getString(5));
				obj.setDeco_type(resultset.getString(6));

			}
			return obj;
		} catch (Exception e) {
			System.out.println("\nException during Getting Particular Food Deatil: " + e.getMessage());
		}

		return null;
	}

	@Override
	public int setOrderDetails(Order order, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		String query = "INSERT INTO order_table(order_id, user_id, package_id, total_order_price, payment_mode, payment_status, event_date, order_date, guest_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try(PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
		{
			pst.setString(1, order.getOrder_id());
			pst.setInt(2, order.getUser_id());
			pst.setInt(3, order.getPackage_id());
			pst.setInt(4, order.getTotal_order_price());
			if(order.getPayMode().equalsIgnoreCase("cash on delivery"))
				pst.setInt(5, 0);
			else
				pst.setInt(5, 1);
			if(order.getPayMode().equalsIgnoreCase("cash on delivery"))
				pst.setString(6, "Pending");
			else
				pst.setString(6, "Waiting");
			pst.setString(7, order.getEvent_date());
			pst.setString(8, order.getOrder_date());
			pst.setInt(9, order.getNumOfGuest());
			
			ans = pst.executeUpdate();
			return ans;
		}catch(Exception e) {System.out.println("Exception Set ORder: " + e.getMessage());}
		return ans;
	}

	@Override
	public List<Order> fetchOrderList(Connection con) {
		// TODO Auto-generated method stub
		List<Order> ans = new ArrayList<Order>();
		String query = "select * from order_table ORDER BY order_date DESC";
		try(PreparedStatement pst = con.prepareStatement(query)){
			ResultSet rst = pst.executeQuery();
			while(rst.next())
			{
				Order obj = new Order();
				obj.setOrder_id(rst.getString("order_id"));
				obj.setUser_id(rst.getInt("user_id"));
				obj.setPackage_id(rst.getInt("package_id"));
				obj.setTotal_order_price(rst.getInt("total_order_price"));
				
				int getPaymentMode = rst.getInt("payment_mode");
				if(getPaymentMode == 1)
					obj.setPayMode("Online Payment");
				else
					obj.setPayMode("Cash On Delivery");
				
				obj.setPaymentStatus(rst.getString("payment_status"));
				obj.setOrderStatus(rst.getString("order_status"));
				obj.setEvent_date(rst.getString("event_date"));
				obj.setOrder_date(rst.getString("order_date"));
				obj.setNumOfGuest(rst.getInt("guest_number"));
				
				
				
				String event_name = new String();
				String pack_type = new String();
				String query2 = "select event_id, package_type from package_table where package_id = ?";
				try(PreparedStatement pst2 = con.prepareStatement(query2)){
					pst2.setInt(1, obj.getPackage_id());
					
					ResultSet rst2 = pst2.executeQuery();
					
					while(rst2.next())
					{
						
						int event_id = rst2.getInt("event_id");
						pack_type = rst2.getString("package_type");
						try(PreparedStatement pst3 = con.prepareStatement("select event_name from event_table where event_id = ?")){
							pst3.setInt(1, event_id);
							ResultSet rst3 = pst3.executeQuery();
							while(rst3.next())
							{
								event_name = rst3.getString("event_name");
							}
						}catch(Exception e) {System.out.println("event _name exp: " + e.getMessage());
						e.printStackTrace();}
					}
				}catch(Exception e) {System.out.println("\nExp Event NAme: " + e.getMessage());
				e.printStackTrace();
				}
				
				obj.setEvent_name(event_name);
				
				obj.setPackage_type(pack_type);
				String getUserName = new String();
				try(PreparedStatement pst4 = con.prepareStatement("select user_name from user_table where user_id = ?")){
					
					pst4.setInt(1, obj.getUser_id());
					
					ResultSet rst4 = pst4.executeQuery();
					
					while(rst4.next()) {
						
						getUserName = rst4.getString("user_name");
					}
					
				}catch(Exception e) {System.out.println("User Name Exp: " + e.getMessage());}
				
				User user = new User();
				user.setUser_name(getUserName);
				obj.setUser_capsule(user);
				
				ans.add(obj);
			}
		}
		catch(Exception e) {System.out.println("Exp During Order List: " + e.getMessage());}
		return ans;
	}

	@Override
	public int fetchOrderUserId(String getOrder_id, Connection con) {
		// TODO Auto-generated method stub
		int user_id = 0;
		
		String query = "select user_id from order_table where order_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1, getOrder_id);
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				user_id = rst.getInt("user_id");
				return user_id;
			}
		}catch(Exception e) {System.out.println("Get Order user id: " + e.getMessage());}
		return user_id;
	}

	@Override
	public Order fetchOrderDetails(String getOrder_id, Connection con) {
		// TODO Auto-generated method stub
		Order obj = new Order();
		
		String query = "select * from order_table where order_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1,getOrder_id.trim());
			
			ResultSet rst = pst.executeQuery();
			while(rst.next())
			{
				obj.setOrder_id(rst.getString("order_id"));
				obj.setUser_id(rst.getInt("user_id"));
				obj.setPackage_id(rst.getInt("package_id"));
				obj.setTotal_order_price(rst.getInt("total_order_price"));
				
				int getPaymentMode = rst.getInt("payment_mode");
				if(getPaymentMode == 1)
					obj.setPayMode("Online Payment");
				else
					obj.setPayMode("Cash On Delivery");
				
				obj.setPaymentStatus(rst.getString("payment_status"));
				obj.setOrderStatus(rst.getString("order_status"));
				obj.setEvent_date(rst.getString("event_date"));
				obj.setOrder_date(rst.getString("order_date"));
				obj.setNumOfGuest(rst.getInt("guest_number"));
				
				
				
				String event_name = new String();
				String pack_type = new String();
				String query2 = "select event_id, package_type from package_table where package_id = ?";
				try(PreparedStatement pst2 = con.prepareStatement(query2)){
					pst2.setInt(1, obj.getPackage_id());
					
					ResultSet rst2 = pst2.executeQuery();
					
					while(rst2.next())
					{
						
						int event_id = rst2.getInt("event_id");
						pack_type = rst2.getString("package_type");
						try(PreparedStatement pst3 = con.prepareStatement("select event_name from event_table where event_id = ?")){
							pst3.setInt(1, event_id);
							ResultSet rst3 = pst3.executeQuery();
							while(rst3.next())
							{
								event_name = rst3.getString("event_name");
							}
						}catch(Exception e) {System.out.println("event _name exp: " + e.getMessage());
						e.printStackTrace();}
					}
				}catch(Exception e) {System.out.println("\nExp Event NAme: " + e.getMessage());
				e.printStackTrace();
				}
				
				obj.setEvent_name(event_name);
				
				obj.setPackage_type(pack_type);
				String getUserName = new String();
				String getAdd = new String();
				String getCon = new String();
				String getmail = new String();
				try(PreparedStatement pst4 = con.prepareStatement("select user_name, user_address, user_contact, user_email from user_table where user_id = ?")){
					
					pst4.setInt(1, obj.getUser_id());
					
					ResultSet rst4 = pst4.executeQuery();
					
					while(rst4.next()) {
						getUserName = rst4.getString("user_name");
						getAdd = rst4.getString("user_address");
						getCon = rst4.getString("user_contact");
						getmail = rst4.getString("user_email");
					}
					
				}catch(Exception e) {System.out.println("User Name Exp: " + e.getMessage());}
				
				User user = new User();
				user.setUser_name(getUserName);
				user.setUser_address(getAdd);
				user.setUser_contact(getCon);
				user.setUser_email(getmail);
				user.setUser_id(obj.getUser_id());
				obj.setUser_capsule(user);
			}
		}
		catch(Exception e) {System.out.println("Exception Get ORder Occured: " + e.getMessage());}
		
		return obj;
	}

	
	public List<PackageCart> fetchPackageCartList2(int package_id, int user_id, Connection con) {
		// TODO Auto-generated method stub
		System.out.println("\nDao Package Cart Called");
		List<PackageCart> listCart = new ArrayList<PackageCart>();
		CateringDaoImpl daoi = new CateringDaoImpl();
		String query = "select * from package_cart_table where package_id = ?";
		try (PreparedStatement pst = con.prepareStatement(query)) {
			System.out.println("\nDao Package Cart");
			pst.setInt(1, package_id);
			//pst.setInt(2, user_id);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				PackageCart obj = new PackageCart();
				obj.setPack_cart_id(rst.getInt(1));
				obj.setUser_id(rst.getInt("user_id"));
				obj.setPackage_id(rst.getInt("package_id"));
				int food_id = rst.getInt("food_item_id");
				Food_items foodObj = new Food_items();
				foodObj = daoi.getProductDetailsId(con, food_id);
				obj.setFood_item_capsule(foodObj);
				obj.setCurr_price(rst.getInt("current_food_price"));
				obj.setCurr_qty(rst.getInt("current_food_qty"));
				listCart.add(obj);
			}
		} catch (Exception e) {
			System.out.println("\nExc. During Pack Cart List: " + e.getMessage());
		}

		return listCart;
	}

	@Override
	public int rejectUserOrder(int usr_id, String order_id, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		String query = "delete from order_table where order_id = ? AND user_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1, order_id);
			pst.setInt(2, usr_id);
			
			ans = pst.executeUpdate();
			return ans;
		}
		catch(Exception e) {System.out.println("\nException Reject: " + e.getMessage());}
		return ans;
	}

	
	public int acceptUserOrder(int usr_id, String order_id, Connection con) {
		// TODO Auto-generated method stub
		String query = "update order_table set order_status = ? where order_id = ? AND user_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, "Accepted");
			pst.setString(2, order_id);
			pst.setInt(3, usr_id);
			
			int ans = pst.executeUpdate();
			return ans;
			
		}catch(Exception e) {System.out.println("\nAccept ORder Exp: " + e.getMessage());}
		return 0;
	}

	@Override
	public List<PackageCart> fetchAdminPackageList(Connection con) {
		// TODO Auto-generated method stub
		String query = "select * from package_table where package_type <> ?";
		List<PackageCart> pcart = new ArrayList<PackageCart>();
		PackageCart obj;
		try(PreparedStatement pst = con.prepareStatement(query))
		{
			
			
			pst.setString(1, "customize");
			
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				PackageCust cust = new PackageCust();
				cust.setEvent_id(rst.getInt("event_id"));
				String event_name = new String();
				try(PreparedStatement pst2 = con.prepareStatement("select event_name from event_table where event_id = ?")){
					pst2.setInt(1, cust.getEvent_id());
					ResultSet rst2 = pst2.executeQuery();
					while(rst2.next())
					{
						event_name = rst2.getString("event_name");
					}
				}catch(Exception e) {System.out.println("event _name : " + e.getMessage());
				e.printStackTrace();}
				
				
				cust.setEvent_name(event_name);
				
				System.out.println("Event Dao Name: " + cust.getEvent_name());
				cust.setPackage_id(rst.getInt("package_id"));
				cust.setPackage_name(rst.getString("package_name"));
				cust.setPackage_price(rst.getInt("package_price"));
				cust.setPackage_type(rst.getString("package_type"));
				cust.setEvent_id(rst.getInt("event_id"));
				//obj.setPackageCapsule(cust);
			
				CateringDaoImpl daoi = new CateringDaoImpl();
				try(PreparedStatement pst3 = con.prepareStatement("select * from package_cart_table where package_id = ?")){
					pst3.setInt(1, cust.getPackage_id());
					
					ResultSet rst3 = pst3.executeQuery();
					
					while(rst3.next())
					{
						obj = new PackageCart();
						Food_items fobj = new Food_items();
						
						fobj = daoi.getProductDetailsId(con, rst3.getInt("food_item_id"));
						
						obj.setFood_item_capsule(fobj);
						
						obj.setCurr_price(rst3.getInt("current_food_price"));
						obj.setCurr_qty(rst3.getInt("current_food_qty"));
						obj.setPackageCapsule(cust);
						pcart.add(obj);
					}
				}catch(Exception e) {System.out.println("Pack Exception : " + e.getMessage());}
			
			}
			
		}
		catch(Exception e) {System.out.println("\nException Admin Package List Occured: " + e.getMessage());}
		
		return pcart;
	}

	@Override
	public List<Integer> fetchPackageIDList(Connection con) {
		// TODO Auto-generated method stub
		
		List<Integer> ans = new ArrayList<Integer>();
		String query = "select package_id from package_table where package_type <> ?";
		
		
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, "customize");
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				ans.add(rst.getInt("package_id"));
			}
			
		}catch(Exception e) {System.out.println("Exception during package id list: " + e.getMessage());}
		
		return ans;
	}

	@Override
	public List<PackageCust> fetchPackageList(Connection con) {
		// TODO Auto-generated method stub
		
		String query = "select * from package_table where package_type <> ? ORDER BY package_id DESC";
		List<PackageCust> listPackage = new ArrayList<PackageCust>();
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, "customize");
			
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				PackageCust obj = new PackageCust();
				
				obj.setPackage_id(rst.getInt("package_id"));
				obj.setEvent_id(rst.getInt("event_id"));
				obj.setPackage_type(rst.getString("package_type"));
				obj.setPackage_price(rst.getInt("package_price"));
				String event_name = new String();
				try(PreparedStatement pst2 = con.prepareStatement("select event_name from event_table where event_id = ?")){
					pst2.setInt(1, obj.getEvent_id());
					ResultSet rst2 = pst2.executeQuery();
					while(rst2.next())
					{
						event_name = rst2.getString("event_name");
					}
				}catch(Exception e) {System.out.println("event _name : " + e.getMessage());
				e.printStackTrace();}
				
				obj.setEvent_name(event_name);
				listPackage.add(obj);
			}
			
		}catch(Exception e) {System.out.println("List Package: " + e.getMessage());}
		
		
		return listPackage;
	}

	
	public int updateAdminPackage(PackageCust obj, Connection con) {
		// TODO Auto-generated method stub
		int ans;
		String query = "update package_table SET package_name = ?, package_type = ?, event_id = ?, package_description = ? WHERE package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, obj.getPackage_name().toLowerCase());
			pst.setString(2, obj.getPackage_type().toLowerCase());
			
			int event_id = 0;
			try (PreparedStatement pst2 = con
					.prepareStatement("select event_id from event_table where event_name = ?")) {
				pst2.setString(1, obj.getEvent_name().toLowerCase());
				ResultSet rst2 = pst2.executeQuery();
				while (rst2.next()) {
					event_id = rst2.getInt(1);
					break;
				}
			} catch (Exception e) {
				System.out.println("\nException Occured get event id: " + e.getMessage());
			}
			System.out.println("EVnet id Dao  :" + event_id);
			
			pst.setInt(3, event_id);
			
			pst.setString(4, obj.getPackage_description().toLowerCase());
			
			pst.setInt(5, obj.getPackage_id());
			
			System.out.println("Pack Name dao :" + obj.getPackage_name() );
			System.out.println("Pack Type dao :" + obj.getPackage_type() );
			System.out.println("Pack Desc dao :" + obj.getPackage_description() );
			System.out.println("Pack ID dao :" + obj.getPackage_id() );
			ans =  pst.executeUpdate();
			return ans;
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured update package: " + e.getMessage());
		}
		
		
		return 0;
	}

	
	public List<Integer> fetchFoodListFromPackage(int package_id, Connection con) {
		// TODO Auto-generated method stub
		List<Integer> ans = new ArrayList<Integer>();
		String sql = "SELECT food_item_id FROM package_cart_table WHERE package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(sql)){
			pst.setInt(1, package_id);
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				ans.add(rst.getInt("food_item_id"));
			}
		
		}catch(Exception e) {System.out.println("Exception Occured Food ID List package: " + e.getMessage());}
		return ans;
	}

	
	public List<Integer> fetchTypeOfPackageList(String eventpacktype, Connection con) {
		// TODO Auto-generated method stub
		
		List<Integer> idList = new ArrayList<Integer>();
		String data[] = eventpacktype.trim().split(",");
		
		String event = data[0];
		String type = data[1];
		System.out.println("Type: " + type);
		if(event.equalsIgnoreCase("all"))
		{
			String query4 = "select package_id from package_table where package_type = ?";
			try(PreparedStatement pst4 = con.prepareStatement(query4)){
				pst4.setString(1, type.trim());
				ResultSet rst4 = pst4.executeQuery();
				while(rst4.next())
				{
					idList.add(rst4.getInt("package_id"));
				}
			}catch(Exception e) {
				System.out.println("Exception Occured All: " + e.getMessage());
			}
			return idList;
		}
		
		
		//List<Integer> current = new ArrayList<Integer>();
		String query = "select package_id, event_id from package_table where package_type = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, type.toLowerCase());
			
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				int pack_id = rst.getInt("package_id");
				int event_id = rst.getInt("event_id");
				String event_name = new String();
				try(PreparedStatement pst2 = con.prepareStatement("select event_name from event_table where event_id = ?")){
					pst2.setInt(1, event_id);
					ResultSet rst2 = pst2.executeQuery();
					while(rst2.next())
					{
						event_name = rst2.getString("event_name");
					}
				}catch(Exception e) {System.out.println("event _name : " + e.getMessage());
				e.printStackTrace();}
				if(event_name.equalsIgnoreCase(event))
				{
					idList.add(pack_id);
				}
			}
			
		}catch(Exception e) {System.out.println("Exception occured type package list: " + e.getMessage());}
		
		return idList;
	}

	@Override
	public int updateUserDetails(User userDetailsObj, Connection con) {
		// TODO Auto-generated method stub
		String query = "update user_table set user_name = ?, user_address = ?, user_contact = ? where user_email = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, userDetailsObj.getUser_name());
			pst.setString(2, userDetailsObj.getUser_address());
			pst.setString(3, userDetailsObj.getUser_contact());
			pst.setString(4, userDetailsObj.getUser_email());
			
			return pst.executeUpdate();
			
		}catch(Exception e) {System.out.println("Error edit profile:" + e.getMessage());}
		
		return 0;
	}

	@Override
	public List<Order> fetchOrderUserList(int user_id, Connection con) {
		// TODO Auto-generated method stub
		List<Order> ans = new ArrayList<Order>();
		String query = "select * from order_table where user_id = ? ORDER BY order_date DESC";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, user_id);
			ResultSet rst = pst.executeQuery();
			while(rst.next())
			{
				Order obj = new Order();
				obj.setOrder_id(rst.getString("order_id"));
				obj.setUser_id(rst.getInt("user_id"));
				obj.setPackage_id(rst.getInt("package_id"));
				obj.setTotal_order_price(rst.getInt("total_order_price"));
				
				int getPaymentMode = rst.getInt("payment_mode");
				if(getPaymentMode == 1)
					obj.setPayMode("Online Payment");
				else
					obj.setPayMode("Cash On Delivery");
				
				obj.setPaymentStatus(rst.getString("payment_status"));
				obj.setOrderStatus(rst.getString("order_status"));
				obj.setEvent_date(rst.getString("event_date"));
				obj.setOrder_date(rst.getString("order_date"));
				obj.setNumOfGuest(rst.getInt("guest_number"));
				
				
				
				String event_name = new String();
				String pack_type = new String();
				String query2 = "select event_id, package_type from package_table where package_id = ?";
				try(PreparedStatement pst2 = con.prepareStatement(query2)){
					pst2.setInt(1, obj.getPackage_id());
					
					ResultSet rst2 = pst2.executeQuery();
					
					while(rst2.next())
					{
						
						int event_id = rst2.getInt("event_id");
						pack_type = rst2.getString("package_type");
						try(PreparedStatement pst3 = con.prepareStatement("select event_name from event_table where event_id = ?")){
							pst3.setInt(1, event_id);
							ResultSet rst3 = pst3.executeQuery();
							while(rst3.next())
							{
								event_name = rst3.getString("event_name");
							}
						}catch(Exception e) {System.out.println("event _name exp: " + e.getMessage());
						e.printStackTrace();}
					}
				}catch(Exception e) {System.out.println("\nExp Event NAme: " + e.getMessage());
				e.printStackTrace();
				}
				
				obj.setEvent_name(event_name);
				
				obj.setPackage_type(pack_type);
				String getUserName = new String();
				try(PreparedStatement pst4 = con.prepareStatement("select user_name from user_table where user_id = ?")){
					
					pst4.setInt(1, obj.getUser_id());
					
					ResultSet rst4 = pst4.executeQuery();
					
					while(rst4.next()) {
						
						getUserName = rst4.getString("user_name");
					}
					
				}catch(Exception e) {System.out.println("User Name Exp: " + e.getMessage());}
				
				User user = new User();
				user.setUser_name(getUserName);
				obj.setUser_capsule(user);
				
				ans.add(obj);
			}
		}
		catch(Exception e) {System.out.println("Exp During Order List: " + e.getMessage());}
		return ans;
	}

	@Override
	public int deleteAdminPackage(int package_id, Connection con) {
		// TODO Auto-generated method stub
		int ans = 0;
		String query = "delete from order_table where package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, package_id);
			ans = pst.executeUpdate();
		}catch(Exception e) {System.out.println("Exception delete order: " + e.getMessage());}
		
		
		query = "delete from package_cart_table where package_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, package_id);
			ans = pst.executeUpdate();
			
			if(ans != 0)
			{
				query = "delete from package_table where package_id = ?";
				try(PreparedStatement pst2 = con.prepareStatement(query)){
					pst2.setInt(1, package_id);
					ans = pst2.executeUpdate();
				}catch(Exception e) {System.out.println("Exception delete package: " + e.getMessage());}
				
			}
			else
			{
				return 0;
			}
			
		}catch(Exception e) {System.out.println("Exception delete package_cart: " + e.getMessage());}
		
		
		return ans;
	}

	
	public static int checkPackageInOrder(int package_id, Connection con)
	{
		String query = "select COUNT(*) FROM order_table WHERE package_id = ?";
		int val = 0;
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, package_id);
			ResultSet st = pst.executeQuery();
			val = 0;
			while(st.next())
			{
				val = st.getInt("count(*)");
			}
			
		}catch(Exception e) {
			System.out.println("Exception Occured: " + e.getMessage());
		}
		System.out.println("VAl : " + val);
		return val;
	}
	public static PackageCust getSinglePackage(int package_id, Connection con)
	{		
		String query = "select * from package_table where package_id = ? AND package_type = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setInt(1, package_id);
			pst.setString(2, "customize");
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				int pack_id = rst.getInt("package_id");
				int ans = checkPackageInOrder(pack_id, con);
				if(ans != 0)
				{
					return null;
				}
				PackageCust obj = new PackageCust();
				obj.setPackage_id(rst.getInt("package_id"));
				obj.setEvent_id(rst.getInt("event_id"));
				obj.setPackage_name(rst.getString("package_name"));
				obj.setPackage_type(rst.getString("package_type"));
				obj.setPackage_price(rst.getInt("package_price"));
				String event_name = new String();
				try(PreparedStatement pst2 = con.prepareStatement("select event_name from event_table where event_id = ?")){
					pst2.setInt(1, obj.getEvent_id());
					ResultSet rst2 = pst2.executeQuery();
					while(rst2.next())
					{
						event_name = rst2.getString("event_name");
					}
				}catch(Exception e) {System.out.println("event _name : " + e.getMessage());
				e.printStackTrace();}
				
				obj.setEvent_name(event_name);
				return obj;
			}
			
		}catch(Exception e) {System.out.println("List Package: " + e.getMessage());}
	
		return null;
	}
	
	@Override
	public List<PackageCust> fetchUserPackId(int user_id, Connection con) {
		// TODO Auto-generated method stub
		
		List<Integer> idList = new ArrayList<Integer>();
		List<PackageCust> plist = new ArrayList<PackageCust>();
		int count = 0;
		
		String query = "select package_id from package_cart_table where user_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setInt(1, user_id);
		
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				PackageCust obj = new PackageCust();
				if(count == 0) {
					count++;
					idList.add(rst.getInt("package_id"));
					obj = getSinglePackage(rst.getInt("package_id"),con);
					if(obj!=null)
						plist.add(obj);
				}
				else
				{
					if(!idList.contains(rst.getInt("package_id")))
					{
						idList.add(rst.getInt("package_id"));
						obj = getSinglePackage(rst.getInt("package_id"), con);
						if(obj!=null)
							plist.add(obj);
					}
				}
			}
			
		}catch(Exception e) {System.out.println("Exception idList: " + e.getMessage());}
		
		return plist;
	}

	@Override
	public int checkEventDate(String getEventDate, Connection con) {
		// TODO Auto-generated method stub
		String query = "select COUNT(*) from order_table where event_date = ? AND order_status = ?";
		int val = 0;
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1, getEventDate);
			pst.setString(2, "accepted");
			ResultSet st = pst.executeQuery();
			val = 0;
			while(st.next())
			{
				val = st.getInt("count(*)");
			}
			
		}catch(Exception e) {
			System.out.println("Exception Occured: " + e.getMessage());
		}
		System.out.println("VAl : " + val);
		return val;
	}

	@Override
	public int saveFeedbackData(int user_id, String message, Connection con) {
		// TODO Auto-generated method stub
		
		String query = "insert into feedback_table(feedback, user_id) values(?, ?)";
		
		try(PreparedStatement pst = con.prepareStatement(query)){
			
			pst.setString(1, message.trim());
			pst.setInt(2, user_id);
			
			return pst.executeUpdate();
		}catch(Exception e) {System.out.println("\nException Occured: " + e.getMessage());}
		return 0;
	}

	
	public List<Feedback> fetchFeedbackData(Connection con) {
		// TODO Auto-generated method stub
		List<Feedback> list = new ArrayList<Feedback>();
		String query = "select * from feedback_table";
		
		try (PreparedStatement ps = con.prepareStatement(query);
				ResultSet resultset = ps.executeQuery()) {
			
			while (resultset.next()) {
				Feedback obj = new Feedback();
				obj.setFeedback(resultset.getString("feedback"));
				obj.setFeedback_id(resultset.getInt("feedback_id"));
				obj.setUser_id(resultset.getInt("user_id"));
				
				
				try(PreparedStatement pst = con.prepareStatement("select user_name from user_table where user_id = ?")){
					pst.setInt(1, obj.getUser_id());
					ResultSet rst = pst.executeQuery();
					while(rst.next()) {
						obj.setUser_name(rst.getString("user_name"));
					}
				}catch(Exception e) {System.out.println("Exception Occured: " + e.getMessage());}
				
				
				list.add(obj);
				
			}
		} catch (Exception e) {
			System.out.println("\nException during getting feedback List: " + e.getMessage());
		}
		
		return list;
	}

	@Override
	public int removeFeedback(int feedback_id, Connection con) {
		// TODO Auto-generated method stub
		
		try(PreparedStatement pst = con.prepareStatement("delete from feedback_table where feedback_id = ?")){
			pst.setInt(1, feedback_id);
			
			return pst.executeUpdate();
		}catch(Exception e) {System.out.println("Exception remove feed: " + e.getMessage());}
		
		return 0;
	}

	@Override
	public int addCategory(String catname, Connection con) {
		// TODO Auto-generated method stub
		
		
		try(PreparedStatement pst = con.prepareStatement("insert into food_item_type(food_item_type_name) values(?)")){
			
			
			pst.setString(1, catname);
			return pst.executeUpdate();
			
		}catch(Exception e) {System.out.println("Exception remove feed: " + e.getMessage());}
		
		
		return 0;
	}

	
	public List<Order> fetchReportData(String stDate, String enDate, Connection con) {
		// TODO Auto-generated method stub
		
		List<Order> ans = new ArrayList<Order>();
		String query = "SELECT * FROM order_table WHERE event_date >= ? AND event_date <= ?";
		
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1, stDate);
			pst.setString(2, enDate);
			ResultSet rst = pst.executeQuery();
			while(rst.next())
			{
				Order obj = new Order();
				obj.setOrder_id(rst.getString("order_id"));
				obj.setUser_id(rst.getInt("user_id"));
				obj.setPackage_id(rst.getInt("package_id"));
				obj.setTotal_order_price(rst.getInt("total_order_price"));
				
				int getPaymentMode = rst.getInt("payment_mode");
				if(getPaymentMode == 1)
					obj.setPayMode("Online Payment");
				else
					obj.setPayMode("Cash On Delivery");
				
				obj.setPaymentStatus(rst.getString("payment_status"));
				obj.setOrderStatus(rst.getString("order_status"));
				obj.setEvent_date(rst.getString("event_date"));
				obj.setOrder_date(rst.getString("order_date"));
				obj.setNumOfGuest(rst.getInt("guest_number"));
				
				
				
				String event_name = new String();
				String pack_type = new String();
				String query2 = "select event_id, package_type from package_table where package_id = ?";
				try(PreparedStatement pst2 = con.prepareStatement(query2)){
					pst2.setInt(1, obj.getPackage_id());
					
					ResultSet rst2 = pst2.executeQuery();
					
					while(rst2.next())
					{
						
						int event_id = rst2.getInt("event_id");
						pack_type = rst2.getString("package_type");
						try(PreparedStatement pst3 = con.prepareStatement("select event_name from event_table where event_id = ?")){
							pst3.setInt(1, event_id);
							ResultSet rst3 = pst3.executeQuery();
							while(rst3.next())
							{
								event_name = rst3.getString("event_name");
							}
						}catch(Exception e) {System.out.println("event _name exp: " + e.getMessage());
						e.printStackTrace();}
					}
				}catch(Exception e) {System.out.println("\nExp Event NAme: " + e.getMessage());
				e.printStackTrace();
				}
				
				obj.setEvent_name(event_name);
				
				obj.setPackage_type(pack_type);
				String getUserName = new String();
				try(PreparedStatement pst4 = con.prepareStatement("select user_name from user_table where user_id = ?")){
					
					pst4.setInt(1, obj.getUser_id());
					
					ResultSet rst4 = pst4.executeQuery();
					
					while(rst4.next()) {
						
						getUserName = rst4.getString("user_name");
					}
					
				}catch(Exception e) {System.out.println("User Name Exp: " + e.getMessage());}
				
				User user = new User();
				user.setUser_name(getUserName);
				obj.setUser_capsule(user);
				
				ans.add(obj);
			}
		}
		catch(Exception e) {System.out.println("Exp During Order List: " + e.getMessage());}

		return ans;
	}

	@Override
	public int setOrderComplete(String order_id, int usr_id, Connection con) {
		// TODO Auto-generated method stub
		
		String query = "update order_table set order_status = ?, payment_status = ? where order_id = ? AND user_id = ?";
		try(PreparedStatement pst = con.prepareStatement(query)){
			pst.setString(1, "completed");
			pst.setString(2, "paid");
			pst.setString(3, order_id);
			pst.setInt(4, usr_id);
			return pst.executeUpdate();
		}catch(Exception e) {System.out.println("Exception Occured Set Complete: " + e.getMessage());}
		return 0;
	}
}