package com.e_catering_system.dao;

import java.sql.Connection;
import java.util.List;

import com.e_catering_system.bean.Decoration;
import com.e_catering_system.bean.Event;
import com.e_catering_system.bean.Feedback;
import com.e_catering_system.bean.Food_items;
import com.e_catering_system.bean.List_of_food_items;
import com.e_catering_system.bean.Order;
import com.e_catering_system.bean.PackageCart;
import com.e_catering_system.bean.PackageCust;
import com.e_catering_system.bean.User;
public interface CateringDao {

	int saveUserDetailsData(User obj, Connection con);

	int getMailDetails(String email, Connection con);

	User checkLoginStatus(User obj2, Connection con);


	User getUserDetailsUsingEmail(String email, Connection con);

	User setUpassword(User obj, String password, Connection con);

	int saveProductDetails(Connection con,Food_items obj);

	List<User> fetchUserListDao(Connection con);

	int fetchCategoryId(Connection con, String getCategory);

	//List<Food_items> fetchProductListDao(Connection con);

	List<Food_items> fetchProductListDao(Connection con);

	Food_items getProductDetailsId(Connection con, int pid);

	int deleteProduct(Connection con, int product_id);

	int updateProduct(Connection con, Food_items obj);

	List<String> getCategoryList(Connection con);

	int savePackageInfo(PackageCust obj, Connection con);

	int getPackageId(PackageCust obj, Connection con);

	//int setPackageData(List_of_food_items obj, Connection con);

	int saveDecoDetails(Connection con, Decoration obj);

	List<Decoration> fetchDecoList(Connection con);

	List_of_food_items getPackageInfo(int pid, Connection con);

	List<Event> fetchEventListDao(Connection con);

	int getFoodName(String foodName, Connection con);

	List<Food_items> selectParticularFoodItemDetail(String foodName, Connection con);

	List<PackageCust> fetchPackList(Connection con);

	int setFoodItemIdIntoCart(int pid, int pack_id, int userID, Connection con);

	List<PackageCart> fetchPackageCartList(int package_id, Connection con);

	List<PackageCart> removeFoodItemFromPackageCart(int foodID, int packID, Connection con);

	int setPackageTotalPrice(int package_id, int total_pack_price, Connection con);

	User getUserDetailsUsingId(int userId, Connection con);

	int setUserAddress(int usr_id, String getAddress, Connection con);

	PackageCust getPackageBean(int package_id, Connection con);

	int updatePackageCartQtyPrice(Connection con, int package_id, String[] arrQty, String[] arrPrices, String[] arrFoodId);

	String getEventName(int pack_id, Connection con);

	int getdecoName(String decoName, Connection con);

	Decoration selectParticularDecoItemDetail(int deco_id, Connection con);

	int setOrderDetails(Order order, Connection con);

	List<Order> fetchOrderList(Connection con);

	int fetchOrderUserId(String getOrder_id, Connection con);

	Order fetchOrderDetails(String getOrder_id, Connection con);

	List<PackageCart> fetchPackageCartList2(int package_id, int user_id, Connection con);

	int rejectUserOrder(int usr_id, String order_id, Connection con);

	int acceptUserOrder(int usr_id, String order_id, Connection con);

	List<PackageCart> fetchAdminPackageList(Connection con);

	List<Integer> fetchPackageIDList(Connection con);

	List<PackageCust> fetchPackageList(Connection con);

	int updateAdminPackage(PackageCust obj, Connection con);

	List<Integer> fetchFoodListFromPackage(int package_id, Connection con);

	List<Integer> fetchTypeOfPackageList(String eventpacktype, Connection con);

	int updateUserDetails(User userDetailsObj, Connection con);

	List<Order> fetchOrderUserList(int user_id, Connection con);

	int deleteAdminPackage(int package_id, Connection con);

	List<PackageCust> fetchUserPackId(int user_id, Connection con);

	int checkEventDate(String getEventDate, Connection con);

	int saveFeedbackData(int user_id, String message, Connection con);

	List<Feedback> fetchFeedbackData(Connection con);

	int removeFeedback(int feedback_id, Connection con);

	int addCategory(String catname, Connection con);

	List<Order> fetchReportData(String stDate, String enDate, Connection con);

	int setOrderComplete(String order_id, int usr_id, Connection con);

}
